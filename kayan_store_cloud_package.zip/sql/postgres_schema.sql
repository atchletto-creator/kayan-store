-- ============================================================================
-- KAYAN STORE — AUTHORITATIVE POSTGRESQL 16 SCHEMA (PHASE 2)
-- Single-Branch, Multi-Device, Offline-First Cloud Architecture
-- ============================================================================

CREATE SEQUENCE IF NOT EXISTS global_server_version_seq START 1;

CREATE TABLE IF NOT EXISTS roles (
    role_key VARCHAR(32) PRIMARY KEY,
    label VARCHAR(100) NOT NULL,
    allowed_routes JSONB NOT NULL DEFAULT '[]'::jsonb,
    can_add_edit_products BOOLEAN NOT NULL DEFAULT FALSE,
    can_delete_items BOOLEAN NOT NULL DEFAULT FALSE,
    can_manage_mdm BOOLEAN NOT NULL DEFAULT FALSE,
    can_export_reset_db BOOLEAN NOT NULL DEFAULT FALSE,
    can_change_theme BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY,
    username VARCHAR(64) UNIQUE NOT NULL,
    display_name VARCHAR(120) NOT NULL,
    role_key VARCHAR(32) NOT NULL REFERENCES roles(role_key),
    password_hash TEXT NOT NULL,
    pin_hash TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    failed_attempts INT NOT NULL DEFAULT 0,
    locked_until TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS registered_devices (
    device_id VARCHAR(64) PRIMARY KEY,
    device_name VARCHAR(120) NOT NULL,
    device_fingerprint TEXT NOT NULL,
    public_key_jwk JSONB,
    status VARCHAR(24) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('PENDING', 'ACTIVE', 'REVOKED')),
    offline_pos_allowed BOOLEAN NOT NULL DEFAULT TRUE,
    max_offline_lease_hours INT NOT NULL DEFAULT 12,
    last_seen_at TIMESTAMPTZ,
    last_sync_version BIGINT NOT NULL DEFAULT 0,
    registered_by UUID REFERENCES users(id),
    revoked_at TIMESTAMPTZ,
    revoked_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS device_sessions (
    session_id VARCHAR(64) PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id),
    device_id VARCHAR(64) NOT NULL REFERENCES registered_devices(device_id),
    refresh_token_hash TEXT NOT NULL,
    offline_lease_expires_at TIMESTAMPTZ NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    is_revoked BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS pos_shifts (
    id VARCHAR(64) PRIMARY KEY,
    device_id VARCHAR(64) REFERENCES registered_devices(device_id),
    user_id UUID REFERENCES users(id),
    name VARCHAR(100) NOT NULL,
    cashier_name VARCHAR(120) NOT NULL,
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ,
    opening_float NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    closing_cash_counted NUMERIC(14,2),
    status VARCHAR(32) NOT NULL DEFAULT 'نشطة',
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS sync_operations_log (
    operation_id VARCHAR(64) PRIMARY KEY,
    idempotency_key VARCHAR(128) UNIQUE NOT NULL,
    device_id VARCHAR(64) NOT NULL REFERENCES registered_devices(device_id),
    user_id VARCHAR(64) NOT NULL,
    entity_type VARCHAR(64) NOT NULL,
    entity_id VARCHAR(128) NOT NULL,
    action_type VARCHAR(64) NOT NULL,
    client_timestamp TIMESTAMPTZ NOT NULL,
    base_server_version BIGINT,
    payload JSONB NOT NULL,
    status VARCHAR(32) NOT NULL CHECK (status IN ('APPLIED', 'CONFLICT', 'REJECTED')),
    resolution_details JSONB,
    assigned_server_version BIGINT NOT NULL,
    processed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sync_change_log (
    server_version BIGINT PRIMARY KEY DEFAULT nextval('global_server_version_seq'),
    entity_type VARCHAR(64) NOT NULL,
    entity_id VARCHAR(128) NOT NULL,
    operation VARCHAR(16) NOT NULL CHECK (operation IN ('UPSERT', 'DELETE')),
    record_data JSONB NOT NULL,
    source_device_id VARCHAR(64),
    source_operation_id VARCHAR(64),
    changed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS general_settings (
    branch_id VARCHAR(32) PRIMARY KEY DEFAULT 'MAIN',
    settings_json JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS categories (
    id VARCHAR(64) PRIMARY KEY,
    code VARCHAR(32) NOT NULL,
    name VARCHAR(150) NOT NULL,
    parent_id VARCHAR(64) REFERENCES categories(id) ON DELETE RESTRICT,
    sort_order INT NOT NULL DEFAULT 1,
    description TEXT,
    icon VARCHAR(64),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_published BOOLEAN NOT NULL DEFAULT TRUE,
    in_pos BOOLEAN NOT NULL DEFAULT TRUE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS brands (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    name_ar VARCHAR(120),
    country VARCHAR(80),
    logo_icon VARCHAR(64),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS models (
    id VARCHAR(64) PRIMARY KEY,
    brand_id VARCHAR(64) NOT NULL REFERENCES brands(id) ON DELETE RESTRICT,
    name VARCHAR(150) NOT NULL,
    device_type VARCHAR(80),
    screen_size VARCHAR(64),
    specs TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS attributes (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    code VARCHAR(64) NOT NULL,
    type VARCHAR(32) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS units (
    id VARCHAR(64) PRIMARY KEY,
    code VARCHAR(32) NOT NULL,
    name VARCHAR(100) NOT NULL,
    symbol VARCHAR(32),
    is_base BOOLEAN NOT NULL DEFAULT FALSE,
    conversion_factor NUMERIC(12,4) NOT NULL DEFAULT 1,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS wallets (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    type VARCHAR(64) NOT NULL,
    provider VARCHAR(120),
    account_number VARCHAR(100),
    balance NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    allow_deposit BOOLEAN NOT NULL DEFAULT TRUE,
    allow_withdraw BOOLEAN NOT NULL DEFAULT TRUE,
    allow_transfer BOOLEAN NOT NULL DEFAULT TRUE,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    has_history BOOLEAN NOT NULL DEFAULT FALSE,
    has_tiered_commission BOOLEAN NOT NULL DEFAULT FALSE,
    commission_step NUMERIC(14,2) NOT NULL DEFAULT 500.00,
    commission_fee_per_step NUMERIC(14,2) NOT NULL DEFAULT 5.00,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS terminals (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    provider VARCHAR(120) NOT NULL,
    serial_number VARCHAR(100),
    linked_safe_id VARCHAR(64) REFERENCES wallets(id) ON DELETE RESTRICT,
    opening_balance NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    current_balance NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    expected_balance NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    commission_rate NUMERIC(6,3) NOT NULL DEFAULT 0.000,
    pricing_mode VARCHAR(32) NOT NULL DEFAULT 'يدوي',
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    has_history BOOLEAN NOT NULL DEFAULT FALSE,
    total_funded NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    total_withdrawn NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS recharge_companies (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    sector VARCHAR(100),
    code VARCHAR(32),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS recharge_services (
    id VARCHAR(64) PRIMARY KEY,
    company_id VARCHAR(64) NOT NULL REFERENCES recharge_companies(id) ON DELETE RESTRICT,
    name VARCHAR(150) NOT NULL,
    category VARCHAR(100),
    cost_rate NUMERIC(10,4) NOT NULL DEFAULT 1.0000,
    sell_rate NUMERIC(10,4) NOT NULL DEFAULT 1.0000,
    commission_percent NUMERIC(6,3) NOT NULL DEFAULT 0.000,
    pricing_mode VARCHAR(32) NOT NULL DEFAULT 'يدوي',
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS service_pricing_matrix (
    id VARCHAR(64) PRIMARY KEY,
    service_id VARCHAR(64) NOT NULL REFERENCES recharge_services(id) ON DELETE CASCADE,
    terminal_id VARCHAR(64) NOT NULL REFERENCES terminals(id) ON DELETE CASCADE,
    custom_commission NUMERIC(6,3) NOT NULL DEFAULT 0.000,
    custom_fee NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS bundles_catalog (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    company_id VARCHAR(64) NOT NULL REFERENCES recharge_companies(id) ON DELETE RESTRICT,
    service_id VARCHAR(64) NOT NULL REFERENCES recharge_services(id) ON DELETE RESTRICT,
    face_value NUMERIC(14,2) NOT NULL,
    cost_price NUMERIC(14,2) NOT NULL,
    selling_price NUMERIC(14,2) NOT NULL,
    terminal_id VARCHAR(64) REFERENCES terminals(id) ON DELETE SET NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS payment_methods (
    id VARCHAR(64) PRIMARY KEY,
    code VARCHAR(32) UNIQUE NOT NULL,
    name VARCHAR(150) NOT NULL,
    in_pos BOOLEAN NOT NULL DEFAULT TRUE,
    in_store BOOLEAN NOT NULL DEFAULT FALSE,
    in_admin BOOLEAN NOT NULL DEFAULT TRUE,
    fee NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    record_json JSONB NOT NULL,
    CONSTRAINT chk_no_credit_in_pos CHECK (NOT (code = 'CREDIT' AND in_pos = TRUE)),
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS delivery_zones (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    governorate VARCHAR(100) NOT NULL,
    fee NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    min_order NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS maintenance_settings (
    branch_id VARCHAR(32) PRIMARY KEY DEFAULT 'MAIN',
    settings_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS products (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    category_id VARCHAR(64) NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
    brand_id VARCHAR(64) REFERENCES brands(id) ON DELETE RESTRICT,
    model_id VARCHAR(64) REFERENCES models(id) ON DELETE SET NULL,
    unit_id VARCHAR(64) NOT NULL REFERENCES units(id) ON DELETE RESTRICT,
    cost_price NUMERIC(14,2) NOT NULL CHECK (cost_price >= 0),
    selling_price NUMERIC(14,2) NOT NULL CHECK (selling_price >= 0),
    stock_level INT NOT NULL DEFAULT 0,
    reserved_stock INT NOT NULL DEFAULT 0 CHECK (reserved_stock >= 0),
    min_stock INT NOT NULL DEFAULT 2,
    barcode VARCHAR(100) NOT NULL,
    is_published BOOLEAN NOT NULL DEFAULT TRUE,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_seed_demo BOOLEAN NOT NULL DEFAULT FALSE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS discounts (
    id VARCHAR(64) PRIMARY KEY,
    code VARCHAR(64) UNIQUE NOT NULL,
    name VARCHAR(150) NOT NULL,
    type VARCHAR(32) NOT NULL,
    value NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    min_order NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    max_discount NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    max_uses INT NOT NULL DEFAULT 100,
    used_count INT NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS inventory_batches (
    batch_id VARCHAR(64) PRIMARY KEY,
    product_id VARCHAR(64) NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    purchase_order_id VARCHAR(64),
    received_qty INT NOT NULL CHECK (received_qty > 0),
    remaining_qty INT NOT NULL CHECK (remaining_qty >= 0),
    manual_unit_cost NUMERIC(14,2) NOT NULL CHECK (manual_unit_cost >= 0),
    received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    notes TEXT,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS stock_movements (
    movement_id VARCHAR(64) PRIMARY KEY,
    product_id VARCHAR(64) NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    batch_id VARCHAR(64) REFERENCES inventory_batches(batch_id),
    movement_type VARCHAR(32) NOT NULL,
    qty_delta INT NOT NULL,
    stock_before INT NOT NULL,
    stock_after INT NOT NULL,
    unit_cost_snapshot NUMERIC(14,2) NOT NULL,
    reference_type VARCHAR(32) NOT NULL,
    reference_id VARCHAR(64) NOT NULL,
    device_id VARCHAR(64),
    actor VARCHAR(120),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS parties (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    type VARCHAR(32) NOT NULL CHECK (type IN ('عميل', 'مورد')),
    phone VARCHAR(64) NOT NULL,
    balance NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    notes TEXT,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS sales (
    id VARCHAR(64) PRIMARY KEY,
    invoice_number VARCHAR(64) UNIQUE NOT NULL,
    sale_date VARCHAR(64) NOT NULL,
    total_amount NUMERIC(14,2) NOT NULL CHECK (total_amount >= 0),
    discount_amount NUMERIC(14,2) NOT NULL DEFAULT 0.00 CHECK (discount_amount >= 0),
    final_amount NUMERIC(14,2) NOT NULL CHECK (final_amount >= 0),
    paid_amount NUMERIC(14,2) NOT NULL CHECK (paid_amount >= final_amount),
    payment_method_id VARCHAR(64) NOT NULL REFERENCES payment_methods(id),
    wallet_id VARCHAR(64) NOT NULL REFERENCES wallets(id),
    customer_id VARCHAR(64) REFERENCES parties(id),
    customer_name VARCHAR(150) NOT NULL,
    cashier VARCHAR(120) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'مكتملة',
    stock_conflict_flagged BOOLEAN NOT NULL DEFAULT FALSE,
    is_seed_demo BOOLEAN NOT NULL DEFAULT FALSE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS sale_items (
    id VARCHAR(64) PRIMARY KEY,
    sale_id VARCHAR(64) NOT NULL REFERENCES sales(id) ON DELETE RESTRICT,
    product_id VARCHAR(64) NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    product_name VARCHAR(200) NOT NULL,
    qty INT NOT NULL CHECK (qty > 0),
    historical_cost_price NUMERIC(14,2) NOT NULL CHECK (historical_cost_price >= 0),
    selling_price NUMERIC(14,2) NOT NULL CHECK (selling_price >= 0),
    item_discount NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    line_total NUMERIC(14,2) NOT NULL CHECK (line_total >= 0)
);

CREATE TABLE IF NOT EXISTS consolidated_invoices (
    id VARCHAR(64) PRIMARY KEY,
    doc_date VARCHAR(64) NOT NULL,
    customer_name VARCHAR(150) NOT NULL,
    total_amount NUMERIC(14,2) NOT NULL,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS returns (
    id VARCHAR(64) PRIMARY KEY,
    return_date VARCHAR(64) NOT NULL,
    sale_id VARCHAR(64) NOT NULL REFERENCES sales(id) ON DELETE RESTRICT,
    invoice_number VARCHAR(64) NOT NULL,
    product_id VARCHAR(64) NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    qty INT NOT NULL CHECK (qty > 0),
    refund_amount NUMERIC(14,2) NOT NULL CHECK (refund_amount >= 0),
    inspection_status VARCHAR(32) NOT NULL CHECK (inspection_status IN ('RESTOCK', 'DAMAGED')),
    restocked BOOLEAN NOT NULL DEFAULT FALSE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS store_orders (
    id VARCHAR(64) PRIMARY KEY,
    order_date VARCHAR(64) NOT NULL,
    customer_name VARCHAR(150) NOT NULL,
    customer_phone VARCHAR(64) NOT NULL,
    zone_id VARCHAR(64) NOT NULL REFERENCES delivery_zones(id),
    payment_method_id VARCHAR(64) NOT NULL REFERENCES payment_methods(id),
    subtotal NUMERIC(14,2) NOT NULL CHECK (subtotal >= 0),
    delivery_fee NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    discount NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    total NUMERIC(14,2) NOT NULL CHECK (total >= 0),
    status VARCHAR(64) NOT NULL,
    is_paid_to_safe BOOLEAN NOT NULL DEFAULT FALSE,
    collected_amount NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    transfer_screenshot_url TEXT,
    is_seed_demo BOOLEAN NOT NULL DEFAULT FALSE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS inventory_reservations (
    id VARCHAR(64) PRIMARY KEY,
    order_id VARCHAR(64) UNIQUE NOT NULL REFERENCES store_orders(id) ON DELETE CASCADE,
    created_at VARCHAR(64) NOT NULL,
    expires_at VARCHAR(64) NOT NULL,
    status VARCHAR(32) NOT NULL CHECK (status IN ('ACTIVE', 'RELEASED', 'COMMITTED')),
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS purchase_orders (
    id VARCHAR(64) PRIMARY KEY,
    po_date VARCHAR(64) NOT NULL,
    supplier_id VARCHAR(64) NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
    supplier_name VARCHAR(150) NOT NULL,
    total_amount NUMERIC(14,2) NOT NULL CHECK (total_amount >= 0),
    paid_amount NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    status VARCHAR(64) NOT NULL,
    is_seed_demo BOOLEAN NOT NULL DEFAULT FALSE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS stock_audit_records (
    id VARCHAR(64) PRIMARY KEY,
    audit_date VARCHAR(64) NOT NULL,
    settled_items_count INT NOT NULL DEFAULT 0,
    auditor VARCHAR(120) NOT NULL,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS wallet_transactions (
    id VARCHAR(64) PRIMARY KEY,
    tx_date VARCHAR(64) NOT NULL,
    wallet_id VARCHAR(64) NOT NULL REFERENCES wallets(id) ON DELETE RESTRICT,
    wallet_name VARCHAR(150) NOT NULL,
    type VARCHAR(150) NOT NULL,
    amount NUMERIC(14,2) NOT NULL,
    commission NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    balance_after NUMERIC(14,2) NOT NULL,
    reference VARCHAR(100),
    reverses_tx_id VARCHAR(64) REFERENCES wallet_transactions(id),
    notes TEXT,
    is_seed_demo BOOLEAN NOT NULL DEFAULT FALSE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS supplier_ledger (
    id VARCHAR(64) PRIMARY KEY,
    supplier_id VARCHAR(64) NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
    tx_date VARCHAR(64) NOT NULL,
    type VARCHAR(150) NOT NULL,
    reference VARCHAR(100),
    debit NUMERIC(14,2) NOT NULL DEFAULT 0.00 CHECK (debit >= 0),
    credit NUMERIC(14,2) NOT NULL DEFAULT 0.00 CHECK (credit >= 0),
    balance NUMERIC(14,2) NOT NULL,
    reverses_entry_id VARCHAR(64) REFERENCES supplier_ledger(id),
    notes TEXT,
    is_seed_demo BOOLEAN NOT NULL DEFAULT FALSE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS expenses (
    id VARCHAR(64) PRIMARY KEY,
    expense_date VARCHAR(64) NOT NULL,
    category VARCHAR(120) NOT NULL,
    amount NUMERIC(14,2) NOT NULL CHECK (amount > 0),
    safe_id VARCHAR(64) NOT NULL REFERENCES wallets(id) ON DELETE RESTRICT,
    reverses_expense_id VARCHAR(64) REFERENCES expenses(id),
    notes TEXT,
    is_seed_demo BOOLEAN NOT NULL DEFAULT FALSE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS recharge_transactions (
    id VARCHAR(64) PRIMARY KEY,
    tx_date VARCHAR(64) NOT NULL,
    terminal_id VARCHAR(64) NOT NULL REFERENCES terminals(id) ON DELETE RESTRICT,
    service_id VARCHAR(64) NOT NULL REFERENCES recharge_services(id) ON DELETE RESTRICT,
    recipient VARCHAR(100) NOT NULL,
    amount NUMERIC(14,2) NOT NULL CHECK (amount > 0),
    deducted_from_terminal NUMERIC(14,2) NOT NULL CHECK (deducted_from_terminal > 0),
    collected_from_customer NUMERIC(14,2) NOT NULL CHECK (collected_from_customer >= deducted_from_terminal),
    net_profit NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    status VARCHAR(32) NOT NULL,
    is_seed_demo BOOLEAN NOT NULL DEFAULT FALSE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS maintenance_tickets (
    id VARCHAR(64) PRIMARY KEY,
    ticket_number VARCHAR(64) UNIQUE NOT NULL,
    ticket_date VARCHAR(64) NOT NULL,
    customer_name VARCHAR(150) NOT NULL,
    customer_phone VARCHAR(64) NOT NULL,
    device_type_id VARCHAR(64) NOT NULL,
    brand_id VARCHAR(64) REFERENCES brands(id),
    fault_type_id VARCHAR(64) NOT NULL,
    stage_id VARCHAR(64) NOT NULL,
    warranty_id VARCHAR(64) NOT NULL,
    estimated_cost NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    paid_deposit NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    status VARCHAR(64) NOT NULL,
    is_seed_demo BOOLEAN NOT NULL DEFAULT FALSE,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

CREATE TABLE IF NOT EXISTS audit_log (
    id VARCHAR(64) PRIMARY KEY,
    timestamp VARCHAR(64) NOT NULL,
    actor VARCHAR(120) NOT NULL,
    action VARCHAR(64) NOT NULL,
    module VARCHAR(100) NOT NULL,
    item_id VARCHAR(128) NOT NULL,
    details TEXT,
    record_json JSONB NOT NULL,
    server_version BIGINT NOT NULL DEFAULT nextval('global_server_version_seq')
);

-- Immutability Triggers for Financial & Audit Tables
CREATE OR REPLACE FUNCTION prevent_ledger_delete_or_mutate()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'IMMUTABLE_LEDGER_VIOLATION: Completed financial, sales, stock movement, and audit records cannot be deleted or modified. Use a reversal entry instead.';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_immutable_wallet_tx BEFORE DELETE OR UPDATE ON wallet_transactions
    FOR EACH ROW EXECUTE FUNCTION prevent_ledger_delete_or_mutate();
CREATE TRIGGER trg_immutable_supplier_ledger BEFORE DELETE OR UPDATE ON supplier_ledger
    FOR EACH ROW EXECUTE FUNCTION prevent_ledger_delete_or_mutate();
CREATE TRIGGER trg_immutable_stock_movements BEFORE DELETE OR UPDATE ON stock_movements
    FOR EACH ROW EXECUTE FUNCTION prevent_ledger_delete_or_mutate();
CREATE TRIGGER trg_immutable_audit_log BEFORE DELETE OR UPDATE ON audit_log
    FOR EACH ROW EXECUTE FUNCTION prevent_ledger_delete_or_mutate();
