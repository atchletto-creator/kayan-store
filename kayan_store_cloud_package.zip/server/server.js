/**
 * KAYAN STORE — Node.js Cloud API & Synchronization Server (Phase 2)
 * Exposes REST endpoints for Auth, Device Management, Outbox Push/Pull Sync,
 * Migration Dry-Run/Commit, and Financial/Inventory Integrity Verification.
 */
const http = require('http');
const crypto = require('crypto');
const path = require('path');
const { spawn } = require('child_process');

const JWT_SECRET = process.env.KAYAN_JWT_SECRET || 'kayan-store-cloud-hmac-secret-2026-alexandria';

function signToken(payload) {
    const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
    const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
    const sig = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
    return `${header}.${body}.${sig}`;
}

function verifyToken(token) {
    if (!token || typeof token !== 'string') throw new Error('MISSING_AUTH_TOKEN');
    const parts = token.split('.');
    if (parts.length !== 3) throw new Error('MALFORMED_TOKEN');
    const expectedSig = crypto.createHmac('sha256', JWT_SECRET).update(`${parts[0]}.${parts[1]}`).digest('base64url');
    if (expectedSig !== parts[2]) throw new Error('INVALID_TOKEN_SIGNATURE');
    return JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
}

function createKayanServer(dbFilePath = ':memory:') {
    const workerPath = path.join(__dirname, 'sql_worker.py');
    const py = spawn('python3', [workerPath, dbFilePath], { stdio: ['pipe', 'pipe', 'inherit'] });

    let reqSeq = 0;
    const pending = new Map();
    let stdoutBuf = '';

    py.stdout.on('data', (chunk) => {
        stdoutBuf += chunk.toString('utf8');
        let idx;
        while ((idx = stdoutBuf.indexOf('\n')) !== -1) {
            const line = stdoutBuf.slice(0, idx).trim();
            stdoutBuf = stdoutBuf.slice(idx + 1);
            if (!line) continue;
            try {
                const msg = JSON.parse(line);
                const handler = pending.get(msg.id);
                if (handler) {
                    pending.delete(msg.id);
                    if (msg.ok) handler.resolve(msg.result);
                    else handler.reject(new Error(msg.error || 'SQL_ERROR'));
                }
            } catch (err) {
                console.error('Worker JSON parse error:', err);
            }
        }
    });

    function rpc(cmd, params = {}) {
        return new Promise((resolve, reject) => {
            const id = ++reqSeq;
            pending.set(id, { resolve, reject });
            py.stdin.write(JSON.stringify({ id, cmd, params }) + '\n');
        });
    }

    const server = http.createServer(async (req, res) => {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Device-Id, X-Idempotency-Key, X-Simulated-Epoch');
        if (req.method === 'OPTIONS') {
            res.writeHead(204);
            return res.end();
        }

        let rawBody = '';
        for await (const chunk of req) rawBody += chunk;
        let body = {};
        if (rawBody) {
            try { body = JSON.parse(rawBody); } catch (e) {}
        }

        const urlObj = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
        const pathname = urlObj.pathname;
        const simEpoch = req.headers['x-simulated-epoch'] ? parseInt(req.headers['x-simulated-epoch'], 10) : Math.floor(Date.now() / 1000);

        const sendJson = (code, data) => {
            res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
            res.end(JSON.stringify(data));
        };

        try {
            if (req.method === 'POST' && pathname === '/api/v1/migration/dry-run') {
                const report = await rpc('MIGRATE_DRY_RUN', { state: body.state });
                return sendJson(200, { ok: true, dryRun: true, report });
            }

            if (req.method === 'POST' && pathname === '/api/v1/migration/commit') {
                const report = await rpc('MIGRATE_COMMIT', { state: body.state });
                return sendJson(200, { ok: true, dryRun: false, report });
            }

            if (req.method === 'POST' && pathname === '/api/v1/auth/login') {
                const authRes = await rpc('AUTH_LOGIN', {
                    role: body.role,
                    pin: body.pin,
                    deviceId: body.deviceId || req.headers['x-device-id'] || 'DEV-POS-1',
                    nowEpoch: simEpoch
                });
                const accessToken = signToken({
                    sessionId: authRes.sessionId,
                    userId: authRes.userId,
                    roleKey: authRes.roleKey,
                    deviceId: authRes.deviceId,
                    exp: simEpoch + 3600
                });
                const offlineLeaseToken = signToken({
                    leaseType: 'OFFLINE_POS_LEASE',
                    userId: authRes.userId,
                    roleKey: authRes.roleKey,
                    deviceId: authRes.deviceId,
                    offlinePosAllowed: authRes.offlinePosAllowed,
                    exp: authRes.offlineLeaseExpiresAt
                });
                return sendJson(200, {
                    ok: true,
                    accessToken,
                    offlineLeaseToken,
                    session: authRes
                });
            }

            // Authenticate protected routes
            const authHeader = req.headers['authorization'] || '';
            const tokenStr = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
            const claims = verifyToken(tokenStr);
            if (simEpoch > claims.exp) {
                return sendJson(401, { ok: false, error: 'AUTH_TOKEN_EXPIRED: انتهت صلاحية جلسة المصادقة، يرجى إعادة تسجيل الدخول' });
            }

            if (req.method === 'POST' && pathname === '/api/v1/devices/revoke') {
                if (claims.roleKey !== 'owner') {
                    return sendJson(403, { ok: false, error: 'FORBIDDEN: إلغاء صلاحية الأجهزة مخصص للمالك فقط' });
                }
                const revRes = await rpc('REVOKE_DEVICE', { deviceId: body.deviceId, reason: body.reason });
                return sendJson(200, { ok: true, result: revRes });
            }

            if (req.method === 'POST' && pathname === '/api/v1/sync/push') {
                // Support simulated mid-flight network drop AFTER DB commit for Test #4
                const dropResponseAfterCommit = Boolean(body.simulateDropResponseAfterCommit);
                const pushRes = await rpc('SYNC_PUSH', {
                    deviceId: body.deviceId || claims.deviceId,
                    operations: body.operations || []
                });
                if (dropResponseAfterCommit) {
                    req.socket.destroy();
                    return;
                }
                return sendJson(200, { ok: true, ...pushRes });
            }

            if (req.method === 'GET' && pathname === '/api/v1/sync/pull') {
                const sinceCursor = parseInt(urlObj.searchParams.get('since_cursor') || '0', 10);
                const deviceId = req.headers['x-device-id'] || claims.deviceId;
                const pullRes = await rpc('SYNC_PULL', { deviceId, sinceCursor });
                return sendJson(200, { ok: true, ...pullRes });
            }

            if (req.method === 'GET' && pathname === '/api/v1/metrics') {
                const metrics = await rpc('GET_SERVER_SNAPSHOT_METRICS', {});
                return sendJson(200, { ok: true, metrics });
            }

            if (req.method === 'POST' && pathname === '/api/v1/test-immutable-delete') {
                await rpc('TEST_IMMUTABLE_DELETE', { table: body.table });
                return sendJson(200, { ok: true });
            }

            return sendJson(404, { ok: false, error: 'ENDPOINT_NOT_FOUND' });
        } catch (err) {
            const msg = err.message || String(err);
            const code = (msg.includes('DEVICE_REVOKED') || msg.includes('ACCOUNT_LOCKED') || msg.includes('INVALID_CREDENTIALS') || msg.includes('DEVICE_UNREGISTERED'))
                ? 403
                : (msg.includes('EXPIRED') || msg.includes('TOKEN') ? 401 : 400);
            return sendJson(code, { ok: false, error: msg });
        }
    });

    server.closeDb = () => {
        try { py.kill(); } catch (e) {}
    };

    return { server, rpc, signToken, verifyToken };
}

module.exports = { createKayanServer, signToken, verifyToken };
