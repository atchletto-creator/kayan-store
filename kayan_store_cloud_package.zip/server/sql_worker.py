#!/usr/bin/env python3
"""
KAYAN STORE — Relational SQL Database Worker (PostgreSQL-Compatible ACID Engine)
Enforces relational Foreign Keys, ACID Transactions, Append-Only Ledger Triggers,
Server Version Sequences, Idempotency Keys, and Financial/Inventory Integrity Rules.
"""
import sys
import json
import sqlite3
import hashlib
import hmac
import time
import uuid
import math
from datetime import datetime, timezone, timedelta

DB_PATH = sys.argv[1] if len(sys.argv) > 1 else ":memory:"

conn = sqlite3.connect(DB_PATH, isolation_level=None)
conn.row_factory = sqlite3.Row
conn.execute("PRAGMA foreign_keys = ON;")
conn.execute("PRAGMA journal_mode = WAL;")

def round2(val):
    return round(float(val or 0.0) + 1e-9, 2)

def init_schema():
    cur = conn.cursor()
    cur.executescript("""
    CREATE TABLE IF NOT EXISTS seq_counter (
        name TEXT PRIMARY KEY,
        val INTEGER NOT NULL
    );
    INSERT OR IGNORE INTO seq_counter (name, val) VALUES ('global_server_version', 0);

    CREATE TABLE IF NOT EXISTS roles (
        role_key TEXT PRIMARY KEY,
        label TEXT NOT NULL,
        allowed_routes TEXT NOT NULL,
        can_add_edit_products INTEGER NOT NULL DEFAULT 0,
        can_delete_items INTEGER NOT NULL DEFAULT 0,
        can_manage_mdm INTEGER NOT NULL DEFAULT 0,
        can_export_reset_db INTEGER NOT NULL DEFAULT 0,
        can_change_theme INTEGER NOT NULL DEFAULT 0,
        server_version INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        display_name TEXT NOT NULL,
        role_key TEXT NOT NULL REFERENCES roles(role_key),
        pin_hash TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1,
        failed_attempts INTEGER NOT NULL DEFAULT 0,
        locked_until INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS registered_devices (
        device_id TEXT PRIMARY KEY,
        device_name TEXT NOT NULL,
        device_fingerprint TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('PENDING', 'ACTIVE', 'REVOKED')),
        offline_pos_allowed INTEGER NOT NULL DEFAULT 1,
        max_offline_lease_hours INTEGER NOT NULL DEFAULT 12,
        last_seen_at TEXT,
        last_sync_version INTEGER NOT NULL DEFAULT 0,
        revoked_at TEXT,
        revoked_reason TEXT
    );

    CREATE TABLE IF NOT EXISTS device_sessions (
        session_id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id),
        device_id TEXT NOT NULL REFERENCES registered_devices(device_id),
        role_key TEXT NOT NULL,
        offline_lease_expires_at INTEGER NOT NULL,
        expires_at INTEGER NOT NULL,
        is_revoked INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS sync_operations_log (
        operation_id TEXT PRIMARY KEY,
        idempotency_key TEXT UNIQUE NOT NULL,
        device_id TEXT NOT NULL REFERENCES registered_devices(device_id),
        user_id TEXT NOT NULL,
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        action_type TEXT NOT NULL,
        client_timestamp TEXT NOT NULL,
        base_server_version INTEGER,
        payload TEXT NOT NULL,
        status TEXT NOT NULL CHECK (status IN ('APPLIED', 'CONFLICT', 'REJECTED')),
        resolution_details TEXT,
        assigned_server_version INTEGER NOT NULL,
        processed_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sync_change_log (
        server_version INTEGER PRIMARY KEY,
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        operation TEXT NOT NULL CHECK (operation IN ('UPSERT', 'DELETE')),
        record_data TEXT NOT NULL,
        source_device_id TEXT,
        source_operation_id TEXT,
        changed_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS general_settings (
        branch_id TEXT PRIMARY KEY,
        settings_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS maintenance_settings (
        branch_id TEXT PRIMARY KEY,
        settings_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS active_shift (
        id TEXT PRIMARY KEY,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS categories (
        id TEXT PRIMARY KEY,
        parent_id TEXT REFERENCES categories(id) ON DELETE RESTRICT,
        name TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS brands (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS models (
        id TEXT PRIMARY KEY,
        brand_id TEXT NOT NULL REFERENCES brands(id) ON DELETE RESTRICT,
        name TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS attributes (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS units (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        conversion_factor REAL NOT NULL DEFAULT 1,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS wallets (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        balance REAL NOT NULL DEFAULT 0.0,
        allow_deposit INTEGER NOT NULL DEFAULT 1,
        allow_withdraw INTEGER NOT NULL DEFAULT 1,
        allow_transfer INTEGER NOT NULL DEFAULT 1,
        is_active INTEGER NOT NULL DEFAULT 1,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS terminals (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        linked_safe_id TEXT REFERENCES wallets(id) ON DELETE RESTRICT,
        opening_balance REAL NOT NULL DEFAULT 0.0,
        current_balance REAL NOT NULL DEFAULT 0.0,
        total_funded REAL NOT NULL DEFAULT 0.0,
        total_withdrawn REAL NOT NULL DEFAULT 0.0,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS recharge_companies (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS recharge_services (
        id TEXT PRIMARY KEY,
        company_id TEXT NOT NULL REFERENCES recharge_companies(id) ON DELETE RESTRICT,
        name TEXT NOT NULL,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS service_pricing_matrix (
        id TEXT PRIMARY KEY,
        service_id TEXT NOT NULL REFERENCES recharge_services(id) ON DELETE CASCADE,
        terminal_id TEXT NOT NULL REFERENCES terminals(id) ON DELETE CASCADE,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS bundles_catalog (
        id TEXT PRIMARY KEY,
        company_id TEXT NOT NULL REFERENCES recharge_companies(id) ON DELETE RESTRICT,
        service_id TEXT NOT NULL REFERENCES recharge_services(id) ON DELETE RESTRICT,
        terminal_id TEXT REFERENCES terminals(id) ON DELETE SET NULL,
        cost_price REAL NOT NULL,
        selling_price REAL NOT NULL,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS payment_methods (
        id TEXT PRIMARY KEY,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        in_pos INTEGER NOT NULL DEFAULT 1,
        in_store INTEGER NOT NULL DEFAULT 0,
        in_admin INTEGER NOT NULL DEFAULT 1,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL,
        CHECK (NOT (code = 'CREDIT' AND in_pos = 1))
    );

    CREATE TABLE IF NOT EXISTS delivery_zones (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        fee REAL NOT NULL DEFAULT 0.0,
        min_order REAL NOT NULL DEFAULT 0.0,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS products (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        category_id TEXT NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
        brand_id TEXT REFERENCES brands(id) ON DELETE RESTRICT,
        model_id TEXT REFERENCES models(id) ON DELETE SET NULL,
        unit_id TEXT NOT NULL REFERENCES units(id) ON DELETE RESTRICT,
        cost_price REAL NOT NULL CHECK (cost_price >= 0),
        selling_price REAL NOT NULL CHECK (selling_price >= 0),
        stock_level INTEGER NOT NULL DEFAULT 0,
        reserved_stock INTEGER NOT NULL DEFAULT 0 CHECK (reserved_stock >= 0),
        barcode TEXT NOT NULL,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS discounts (
        id TEXT PRIMARY KEY,
        code TEXT UNIQUE NOT NULL,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS inventory_batches (
        batch_id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
        purchase_order_id TEXT,
        received_qty INTEGER NOT NULL CHECK (received_qty > 0),
        remaining_qty INTEGER NOT NULL CHECK (remaining_qty >= 0),
        manual_unit_cost REAL NOT NULL CHECK (manual_unit_cost >= 0),
        received_at TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS stock_movements (
        movement_id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
        movement_type TEXT NOT NULL,
        qty_delta INTEGER NOT NULL,
        stock_before INTEGER NOT NULL,
        stock_after INTEGER NOT NULL,
        unit_cost_snapshot REAL NOT NULL,
        reference_type TEXT NOT NULL,
        reference_id TEXT NOT NULL,
        device_id TEXT,
        created_at TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS parties (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT NOT NULL CHECK (type IN ('عميل', 'مورد')),
        phone TEXT NOT NULL,
        balance REAL NOT NULL DEFAULT 0.0,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sales (
        id TEXT PRIMARY KEY,
        invoice_number TEXT UNIQUE NOT NULL,
        sale_date TEXT NOT NULL,
        total_amount REAL NOT NULL CHECK (total_amount >= 0),
        discount_amount REAL NOT NULL DEFAULT 0.0,
        final_amount REAL NOT NULL CHECK (final_amount >= 0),
        paid_amount REAL NOT NULL CHECK (paid_amount >= final_amount),
        payment_method_id TEXT NOT NULL REFERENCES payment_methods(id),
        wallet_id TEXT NOT NULL REFERENCES wallets(id),
        customer_id TEXT REFERENCES parties(id),
        stock_conflict_flagged INTEGER NOT NULL DEFAULT 0,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sale_items (
        id TEXT PRIMARY KEY,
        sale_id TEXT NOT NULL REFERENCES sales(id) ON DELETE RESTRICT,
        product_id TEXT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
        qty INTEGER NOT NULL CHECK (qty > 0),
        historical_cost_price REAL NOT NULL CHECK (historical_cost_price >= 0),
        selling_price REAL NOT NULL CHECK (selling_price >= 0),
        line_total REAL NOT NULL CHECK (line_total >= 0)
    );

    CREATE TABLE IF NOT EXISTS consolidated_invoices (
        id TEXT PRIMARY KEY,
        total_amount REAL NOT NULL,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS returns (
        id TEXT PRIMARY KEY,
        sale_id TEXT NOT NULL REFERENCES sales(id) ON DELETE RESTRICT,
        product_id TEXT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
        qty INTEGER NOT NULL CHECK (qty > 0),
        refund_amount REAL NOT NULL CHECK (refund_amount >= 0),
        inspection_status TEXT NOT NULL CHECK (inspection_status IN ('RESTOCK', 'DAMAGED')),
        restocked INTEGER NOT NULL DEFAULT 0,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS store_orders (
        id TEXT PRIMARY KEY,
        zone_id TEXT NOT NULL REFERENCES delivery_zones(id),
        payment_method_id TEXT NOT NULL REFERENCES payment_methods(id),
        total REAL NOT NULL CHECK (total >= 0),
        status TEXT NOT NULL,
        is_paid_to_safe INTEGER NOT NULL DEFAULT 0,
        collected_amount REAL NOT NULL DEFAULT 0.0,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS inventory_reservations (
        id TEXT PRIMARY KEY,
        order_id TEXT UNIQUE NOT NULL REFERENCES store_orders(id) ON DELETE CASCADE,
        status TEXT NOT NULL CHECK (status IN ('ACTIVE', 'RELEASED', 'COMMITTED')),
        expires_at TEXT NOT NULL,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS purchase_orders (
        id TEXT PRIMARY KEY,
        supplier_id TEXT NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
        total_amount REAL NOT NULL CHECK (total_amount >= 0),
        paid_amount REAL NOT NULL DEFAULT 0.0,
        status TEXT NOT NULL,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS stock_audit_records (
        id TEXT PRIMARY KEY,
        settled_items_count INTEGER NOT NULL DEFAULT 0,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS wallet_transactions (
        id TEXT PRIMARY KEY,
        tx_date TEXT NOT NULL,
        wallet_id TEXT NOT NULL REFERENCES wallets(id) ON DELETE RESTRICT,
        type TEXT NOT NULL,
        amount REAL NOT NULL,
        commission REAL NOT NULL DEFAULT 0.0,
        balance_after REAL NOT NULL,
        reference TEXT,
        reverses_tx_id TEXT REFERENCES wallet_transactions(id),
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS supplier_ledger (
        id TEXT PRIMARY KEY,
        supplier_id TEXT NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
        tx_date TEXT NOT NULL,
        type TEXT NOT NULL,
        reference TEXT,
        debit REAL NOT NULL DEFAULT 0.0,
        credit REAL NOT NULL DEFAULT 0.0,
        balance REAL NOT NULL,
        reverses_entry_id TEXT REFERENCES supplier_ledger(id),
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS expenses (
        id TEXT PRIMARY KEY,
        expense_date TEXT NOT NULL,
        category TEXT NOT NULL,
        amount REAL NOT NULL CHECK (amount > 0),
        safe_id TEXT NOT NULL REFERENCES wallets(id) ON DELETE RESTRICT,
        reverses_expense_id TEXT REFERENCES expenses(id),
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS recharge_transactions (
        id TEXT PRIMARY KEY,
        terminal_id TEXT NOT NULL REFERENCES terminals(id) ON DELETE RESTRICT,
        service_id TEXT NOT NULL REFERENCES recharge_services(id) ON DELETE RESTRICT,
        deducted_from_terminal REAL NOT NULL CHECK (deducted_from_terminal > 0),
        collected_from_customer REAL NOT NULL CHECK (collected_from_customer >= deducted_from_terminal),
        net_profit REAL NOT NULL DEFAULT 0.0,
        status TEXT NOT NULL,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS maintenance_tickets (
        id TEXT PRIMARY KEY,
        ticket_number TEXT UNIQUE NOT NULL,
        device_type_id TEXT NOT NULL,
        brand_id TEXT REFERENCES brands(id),
        fault_type_id TEXT NOT NULL,
        stage_id TEXT NOT NULL,
        warranty_id TEXT NOT NULL,
        estimated_cost REAL NOT NULL DEFAULT 0.0,
        paid_deposit REAL NOT NULL DEFAULT 0.0,
        status TEXT NOT NULL,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_log (
        id TEXT PRIMARY KEY,
        timestamp TEXT NOT NULL,
        actor TEXT NOT NULL,
        action TEXT NOT NULL,
        module TEXT NOT NULL,
        item_id TEXT NOT NULL,
        details TEXT,
        record_json TEXT NOT NULL,
        server_version INTEGER NOT NULL
    );

    -- Immutability Triggers: Prevent UPDATE or DELETE on completed ledger/audit rows
    CREATE TRIGGER IF NOT EXISTS trg_no_delete_wallet_tx BEFORE DELETE ON wallet_transactions
    BEGIN
        SELECT RAISE(ABORT, 'IMMUTABLE_LEDGER_VIOLATION: Cannot delete completed wallet_transactions. Use a reversal entry.');
    END;
    CREATE TRIGGER IF NOT EXISTS trg_no_update_wallet_tx BEFORE UPDATE ON wallet_transactions
    BEGIN
        SELECT RAISE(ABORT, 'IMMUTABLE_LEDGER_VIOLATION: Cannot modify completed wallet_transactions. Use a reversal entry.');
    END;
    CREATE TRIGGER IF NOT EXISTS trg_no_delete_supplier_ledger BEFORE DELETE ON supplier_ledger
    BEGIN
        SELECT RAISE(ABORT, 'IMMUTABLE_LEDGER_VIOLATION: Cannot delete completed supplier_ledger entries.');
    END;
    CREATE TRIGGER IF NOT EXISTS trg_no_delete_sales BEFORE DELETE ON sales
    BEGIN
        SELECT RAISE(ABORT, 'IMMUTABLE_LEDGER_VIOLATION: Sales invoices are append-only and cannot be deleted.');
    END;
    CREATE TRIGGER IF NOT EXISTS trg_no_delete_audit_log BEFORE DELETE ON audit_log
    BEGIN
        SELECT RAISE(ABORT, 'IMMUTABLE_LEDGER_VIOLATION: Audit log entries are append-only and cannot be deleted.');
    END;
    """)

def next_server_version(cur):
    cur.execute("UPDATE seq_counter SET val = val + 1 WHERE name = 'global_server_version'")
    cur.execute("SELECT val FROM seq_counter WHERE name = 'global_server_version'")
    return cur.fetchone()["val"]

def append_change_log(cur, entity_type, entity_id, operation, record_obj, device_id=None, op_id=None):
    sv = next_server_version(cur)
    if isinstance(record_obj, dict):
        record_obj["_serverVersion"] = sv
        record_obj["_syncStatus"] = "SYNCED"
    cur.execute("""
        INSERT INTO sync_change_log (server_version, entity_type, entity_id, operation, record_data, source_device_id, source_operation_id, changed_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (sv, entity_type, str(entity_id), operation, json.dumps(record_obj, ensure_ascii=False), device_id, op_id, datetime.now(timezone.utc).isoformat()))
    return sv

def append_audit(cur, actor, action, module, item_id, details, device_id=None):
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    aud_id = f"AUD-{uuid.uuid4().hex[:10].upper()}"
    entry = {
        "id": aud_id,
        "timestamp": now_str,
        "actor": actor,
        "action": action,
        "module": module,
        "itemId": str(item_id),
        "details": details,
        "deviceId": device_id
    }
    sv = append_change_log(cur, "auditLog", aud_id, "UPSERT", entry, device_id, None)
    cur.execute("""
        INSERT INTO audit_log (id, timestamp, actor, action, module, item_id, details, record_json, server_version)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (aud_id, now_str, actor, action, module, str(item_id), details, json.dumps(entry, ensure_ascii=False), sv))
    return entry

def migrate_state_into_db(cur, state, dry_run=False):
    # Normalize and insert all 34 entities from state
    # 1. Roles & Users
    rp = state.get("rolePermissions", {})
    for r_key, r_cfg in rp.items():
        sv = append_change_log(cur, "rolePermissions", r_key, "UPSERT", r_cfg)
        cur.execute("""
            INSERT OR REPLACE INTO roles (role_key, label, allowed_routes, can_add_edit_products, can_delete_items, can_manage_mdm, can_export_reset_db, can_change_theme, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            r_key, r_cfg.get("label", r_key), json.dumps(r_cfg.get("allowedRoutes", []), ensure_ascii=False),
            1 if r_cfg.get("canAddEditProducts") else 0,
            1 if r_cfg.get("canDeleteItems") else 0,
            1 if r_cfg.get("canManageMdm") else 0,
            1 if r_cfg.get("canExportResetDb") else 0,
            1 if r_cfg.get("canChangeTheme") else 0,
            sv
        ))

    gen = dict(state.get("generalSettings", {}))
    owner_hash = gen.get("ownerPinHash") or hashlib.sha256(b"2026").hexdigest()
    manager_hash = gen.get("managerPinHash") or hashlib.sha256(b"1122").hexdigest()
    cashier_hash = gen.get("cashierPinHash") or hashlib.sha256(b"0000").hexdigest()
    # Strip any plaintext PINs from generalSettings
    for pk in ("ownerPin", "managerPin", "cashierPin"):
        gen.pop(pk, None)

    default_users = [
        ("USR-OWNER", "owner", "المالك (Owner)", "owner", owner_hash),
        ("USR-MANAGER", "manager", "مدير الفرع (Manager)", "manager", manager_hash),
        ("USR-CASHIER", "cashier", "كاشير (Cashier)", "cashier", cashier_hash),
    ]
    for uid, uname, dname, rkey, phash in default_users:
        cur.execute("""
            INSERT OR IGNORE INTO users (id, username, display_name, role_key, pin_hash, is_active, failed_attempts, locked_until)
            VALUES (?, ?, ?, ?, ?, 1, 0, 0)
        """, (uid, uname, dname, rkey, phash))

    # Default Registered Devices for Branch Multi-Device Operations
    default_devices = [
        ("DEV-POS-1", "جهاز الكاشير الرئيسي - فرع العماروة #1", "FP-POS-1", 1, 12),
        ("DEV-POS-2", "جهاز الكاشير الاحتياطي - فرع العماروة #2", "FP-POS-2", 1, 12),
        ("DEV-MGR-TAB", "تابلت مدير المعرض والمخزن", "FP-MGR-TAB", 1, 12),
        ("DEV-OWNER", "جهاز المالك للإدارة والرقابة", "FP-OWNER", 1, 24),
    ]
    for did, dname, dfp, off_ok, lease_h in default_devices:
        cur.execute("""
            INSERT OR IGNORE INTO registered_devices (device_id, device_name, device_fingerprint, status, offline_pos_allowed, max_offline_lease_hours, last_seen_at, last_sync_version)
            VALUES (?, ?, ?, 'ACTIVE', ?, ?, ?, 0)
        """, (did, dname, dfp, off_ok, lease_h, datetime.now(timezone.utc).isoformat()))

    # 2. General Settings, Maintenance Settings, Active Shift
    sv = append_change_log(cur, "generalSettings", "MAIN", "UPSERT", gen)
    cur.execute("INSERT OR REPLACE INTO general_settings (branch_id, settings_json, server_version) VALUES ('MAIN', ?, ?)",
                (json.dumps(gen, ensure_ascii=False), sv))

    ms = state.get("maintenanceSettings", {})
    sv = append_change_log(cur, "maintenanceSettings", "MAIN", "UPSERT", ms)
    cur.execute("INSERT OR REPLACE INTO maintenance_settings (branch_id, settings_json, server_version) VALUES ('MAIN', ?, ?)",
                (json.dumps(ms, ensure_ascii=False), sv))

    ash = state.get("activeShift", {"id": "SHF-MAIN-1", "name": "الوردية الحالية", "cashier": "أحمد موسى", "status": "نشطة"})
    sv = append_change_log(cur, "activeShift", ash.get("id", "SHF-MAIN-1"), "UPSERT", ash)
    cur.execute("INSERT OR REPLACE INTO active_shift (id, record_json, server_version) VALUES (?, ?, ?)",
                (ash.get("id", "SHF-MAIN-1"), json.dumps(ash, ensure_ascii=False), sv))

    # 3. Categories (Insert parents first, then children)
    cats = state.get("categories", [])
    cat_ids = {c["id"] for c in cats}
    sorted_cats = sorted(cats, key=lambda c: 0 if not c.get("parentId") or c.get("parentId") not in cat_ids else 1)
    for c in sorted_cats:
        c_copy = dict(c)
        parent_id = c_copy.get("parentId") if c_copy.get("parentId") in cat_ids else None
        sv = append_change_log(cur, "categories", c_copy["id"], "UPSERT", c_copy)
        cur.execute("""
            INSERT OR REPLACE INTO categories (id, parent_id, name, is_active, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (c_copy["id"], parent_id, c_copy["name"], 1 if c_copy.get("isActive", True) else 0, json.dumps(c_copy, ensure_ascii=False), sv))

    # 4. Brands & Models
    for b in state.get("brands", []):
        b_copy = dict(b)
        sv = append_change_log(cur, "brands", b_copy["id"], "UPSERT", b_copy)
        cur.execute("INSERT OR REPLACE INTO brands (id, name, is_active, record_json, server_version) VALUES (?, ?, ?, ?, ?)",
                    (b_copy["id"], b_copy["name"], 1 if b_copy.get("isActive", True) else 0, json.dumps(b_copy, ensure_ascii=False), sv))

    for m in state.get("models", []):
        m_copy = dict(m)
        sv = append_change_log(cur, "models", m_copy["id"], "UPSERT", m_copy)
        cur.execute("INSERT OR REPLACE INTO models (id, brand_id, name, is_active, record_json, server_version) VALUES (?, ?, ?, ?, ?, ?)",
                    (m_copy["id"], m_copy["brandId"], m_copy["name"], 1 if m_copy.get("isActive", True) else 0, json.dumps(m_copy, ensure_ascii=False), sv))

    # 5. Attributes & Units
    for a in state.get("attributes", []):
        a_copy = dict(a)
        sv = append_change_log(cur, "attributes", a_copy["id"], "UPSERT", a_copy)
        cur.execute("INSERT OR REPLACE INTO attributes (id, name, record_json, server_version) VALUES (?, ?, ?, ?)",
                    (a_copy["id"], a_copy["name"], json.dumps(a_copy, ensure_ascii=False), sv))

    for u in state.get("units", []):
        u_copy = dict(u)
        sv = append_change_log(cur, "units", u_copy["id"], "UPSERT", u_copy)
        cur.execute("INSERT OR REPLACE INTO units (id, name, conversion_factor, record_json, server_version) VALUES (?, ?, ?, ?, ?)",
                    (u_copy["id"], u_copy["name"], float(u_copy.get("conversionFactor", 1)), json.dumps(u_copy, ensure_ascii=False), sv))

    # 6. Wallets & Terminals
    for w in state.get("wallets", []):
        w_copy = dict(w)
        w_copy["balance"] = round2(w_copy.get("balance", 0))
        sv = append_change_log(cur, "wallets", w_copy["id"], "UPSERT", w_copy)
        cur.execute("""
            INSERT OR REPLACE INTO wallets (id, name, type, balance, allow_deposit, allow_withdraw, allow_transfer, is_active, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            w_copy["id"], w_copy["name"], w_copy["type"], w_copy["balance"],
            1 if w_copy.get("allowDeposit", True) else 0,
            1 if w_copy.get("allowWithdraw", True) else 0,
            1 if w_copy.get("allowTransfer", True) else 0,
            1 if w_copy.get("isActive", True) else 0,
            json.dumps(w_copy, ensure_ascii=False), sv
        ))

    for t in state.get("terminals", []):
        t_copy = dict(t)
        t_copy["currentBalance"] = round2(t_copy.get("currentBalance", 0))
        sv = append_change_log(cur, "terminals", t_copy["id"], "UPSERT", t_copy)
        cur.execute("""
            INSERT OR REPLACE INTO terminals (id, name, linked_safe_id, opening_balance, current_balance, total_funded, total_withdrawn, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            t_copy["id"], t_copy["name"], t_copy.get("linkedSafeId", "WLT-4"),
            round2(t_copy.get("openingBalance", 0)), t_copy["currentBalance"],
            round2(t_copy.get("totalFunded", 0)), round2(t_copy.get("totalWithdrawn", 0)),
            json.dumps(t_copy, ensure_ascii=False), sv
        ))

    # 7. Recharge Companies, Services, Pricing Matrix, Bundles
    for rc in state.get("rechargeCompanies", []):
        rc_copy = dict(rc)
        sv = append_change_log(cur, "rechargeCompanies", rc_copy["id"], "UPSERT", rc_copy)
        cur.execute("INSERT OR REPLACE INTO recharge_companies (id, name, record_json, server_version) VALUES (?, ?, ?, ?)",
                    (rc_copy["id"], rc_copy["name"], json.dumps(rc_copy, ensure_ascii=False), sv))

    for rs in state.get("rechargeServices", []):
        rs_copy = dict(rs)
        sv = append_change_log(cur, "rechargeServices", rs_copy["id"], "UPSERT", rs_copy)
        cur.execute("INSERT OR REPLACE INTO recharge_services (id, company_id, name, record_json, server_version) VALUES (?, ?, ?, ?, ?)",
                    (rs_copy["id"], rs_copy["companyId"], rs_copy["name"], json.dumps(rs_copy, ensure_ascii=False), sv))

    for spm in state.get("servicePricingMatrix", []):
        spm_copy = dict(spm)
        sv = append_change_log(cur, "servicePricingMatrix", spm_copy["id"], "UPSERT", spm_copy)
        cur.execute("INSERT OR REPLACE INTO service_pricing_matrix (id, service_id, terminal_id, record_json, server_version) VALUES (?, ?, ?, ?, ?)",
                    (spm_copy["id"], spm_copy["serviceId"], spm_copy["terminalId"], json.dumps(spm_copy, ensure_ascii=False), sv))

    for bnd in state.get("bundlesCatalog", []):
        bnd_copy = dict(bnd)
        sv = append_change_log(cur, "bundlesCatalog", bnd_copy["id"], "UPSERT", bnd_copy)
        cur.execute("""
            INSERT OR REPLACE INTO bundles_catalog (id, company_id, service_id, terminal_id, cost_price, selling_price, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            bnd_copy["id"], bnd_copy["companyId"], bnd_copy["serviceId"], bnd_copy.get("terminalId"),
            round2(bnd_copy.get("costPrice", 0)), round2(bnd_copy.get("sellingPrice", 0)),
            json.dumps(bnd_copy, ensure_ascii=False), sv
        ))

    # 8. Payment Methods (Enforce No Customer Credit Sales in POS!)
    for pm in state.get("paymentMethods", []):
        pm_copy = dict(pm)
        if pm_copy.get("code") == "CREDIT":
            pm_copy["inPos"] = False
            pm_copy["inStore"] = False
            pm_copy["isActive"] = False
        sv = append_change_log(cur, "paymentMethods", pm_copy["id"], "UPSERT", pm_copy)
        cur.execute("""
            INSERT OR REPLACE INTO payment_methods (id, code, name, in_pos, in_store, in_admin, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            pm_copy["id"], pm_copy["code"], pm_copy["name"],
            1 if pm_copy.get("inPos") else 0,
            1 if pm_copy.get("inStore") else 0,
            1 if pm_copy.get("inAdmin") else 0,
            json.dumps(pm_copy, ensure_ascii=False), sv
        ))

    # 9. Delivery Zones
    for dz in state.get("deliveryZones", []):
        dz_copy = dict(dz)
        sv = append_change_log(cur, "deliveryZones", dz_copy["id"], "UPSERT", dz_copy)
        cur.execute("INSERT OR REPLACE INTO delivery_zones (id, name, fee, min_order, record_json, server_version) VALUES (?, ?, ?, ?, ?, ?)",
                    (dz_copy["id"], dz_copy["name"], round2(dz_copy.get("fee", 0)), round2(dz_copy.get("minOrder", 0)), json.dumps(dz_copy, ensure_ascii=False), sv))

    # 10. Products & Initial Stock Batches/Movements
    prod_cost_map = {}
    for p in state.get("products", []):
        p_copy = dict(p)
        # Normalize compatibleModelIds / compatibleModels so both keys exist cleanly
        compat = p_copy.get("compatibleModelIds") or p_copy.get("compatibleModels") or ([p_copy["modelId"]] if p_copy.get("modelId") else [])
        p_copy["compatibleModelIds"] = compat
        p_copy["compatibleModels"] = compat
        p_copy["costPrice"] = round2(p_copy.get("costPrice", 0))
        p_copy["sellingPrice"] = round2(p_copy.get("sellingPrice", 0))
        p_copy["stockLevel"] = int(p_copy.get("stockLevel", 0))
        p_copy["reservedStock"] = int(p_copy.get("reservedStock", 0))
        prod_cost_map[p_copy["id"]] = p_copy["costPrice"]

        sv = append_change_log(cur, "products", p_copy["id"], "UPSERT", p_copy)
        cur.execute("""
            INSERT OR REPLACE INTO products (id, name, category_id, brand_id, model_id, unit_id, cost_price, selling_price, stock_level, reserved_stock, barcode, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            p_copy["id"], p_copy["name"], p_copy["categoryId"], p_copy.get("brandId"),
            p_copy.get("modelId"), p_copy.get("unitId", "UNT-1"),
            p_copy["costPrice"], p_copy["sellingPrice"], p_copy["stockLevel"], p_copy["reservedStock"],
            p_copy.get("barcode", ""), json.dumps(p_copy, ensure_ascii=False), sv
        ))
        if p_copy["stockLevel"] > 0:
            batch_id = f"BCH-INIT-{p_copy['id']}"
            cur.execute("""
                INSERT OR IGNORE INTO inventory_batches (batch_id, product_id, purchase_order_id, received_qty, remaining_qty, manual_unit_cost, received_at, server_version)
                VALUES (?, ?, 'INITIAL_SEED', ?, ?, ?, ?, ?)
            """, (batch_id, p_copy["id"], p_copy["stockLevel"], p_copy["stockLevel"], p_copy["costPrice"], datetime.now(timezone.utc).isoformat(), sv))
            cur.execute("""
                INSERT OR IGNORE INTO stock_movements (movement_id, product_id, movement_type, qty_delta, stock_before, stock_after, unit_cost_snapshot, reference_type, reference_id, device_id, created_at, server_version)
                VALUES (?, ?, 'INITIAL_SEED', ?, 0, ?, ?, 'MIGRATION', 'INITIAL_SEED', 'SERVER', ?, ?)
            """, (f"MOV-INIT-{p_copy['id']}", p_copy["id"], p_copy["stockLevel"], p_copy["stockLevel"], p_copy["costPrice"], datetime.now(timezone.utc).isoformat(), sv))

    # 11. Discounts
    for d in state.get("discounts", []):
        d_copy = dict(d)
        sv = append_change_log(cur, "discounts", d_copy["id"], "UPSERT", d_copy)
        cur.execute("INSERT OR REPLACE INTO discounts (id, code, record_json, server_version) VALUES (?, ?, ?, ?)",
                    (d_copy["id"], d_copy["code"], json.dumps(d_copy, ensure_ascii=False), sv))

    # 12. Parties
    for pt in state.get("parties", []):
        pt_copy = dict(pt)
        sv = append_change_log(cur, "parties", pt_copy["id"], "UPSERT", pt_copy)
        cur.execute("INSERT OR REPLACE INTO parties (id, name, type, phone, balance, record_json, server_version) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (pt_copy["id"], pt_copy["name"], pt_copy["type"], pt_copy.get("phone", ""), round2(pt_copy.get("balance", 0)), json.dumps(pt_copy, ensure_ascii=False), sv))

    # 13. Sales & Sale Items (with backfilled historical cost snapshots!)
    for s in state.get("sales", []):
        s_copy = dict(s)
        s_copy["isSeedDemo"] = (s_copy["id"] in ("SAL-1", "SAL-2"))
        items = s_copy.get("items", [])
        norm_items = []
        for idx, it in enumerate(items):
            it_copy = dict(it)
            pid = it_copy.get("productId")
            if "costPrice" not in it_copy or it_copy["costPrice"] is None:
                it_copy["costPrice"] = prod_cost_map.get(pid, 0.0)
            it_copy["historicalCostPrice"] = round2(it_copy["costPrice"])
            norm_items.append(it_copy)
        s_copy["items"] = norm_items
        final_amt = round2(s_copy.get("finalAmount", 0))
        paid_amt = round2(s_copy.get("paidAmount", final_amt))
        if paid_amt < final_amt:
            paid_amt = final_amt
        s_copy["paidAmount"] = paid_amt
        sv = append_change_log(cur, "sales", s_copy["id"], "UPSERT", s_copy)
        cur.execute("""
            INSERT OR REPLACE INTO sales (id, invoice_number, sale_date, total_amount, discount_amount, final_amount, paid_amount, payment_method_id, wallet_id, customer_id, stock_conflict_flagged, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            s_copy["id"], s_copy["invoiceNumber"], s_copy.get("date", ""),
            round2(s_copy.get("totalAmount", final_amt)), round2(s_copy.get("discountAmount", 0)),
            final_amt, paid_amt, s_copy.get("paymentMethodId", "PM-1"), s_copy.get("walletId", "WLT-4"),
            s_copy.get("customerId"), 1 if s_copy.get("stockConflictFlagged") else 0,
            json.dumps(s_copy, ensure_ascii=False), sv
        ))
        for idx, it_copy in enumerate(norm_items):
            qty = int(it_copy.get("qty") or it_copy.get("quantity") or 1)
            sell_p = round2(it_copy.get("price") or it_copy.get("sellingPrice") or 0)
            cur.execute("""
                INSERT OR REPLACE INTO sale_items (id, sale_id, product_id, qty, historical_cost_price, selling_price, line_total)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (f"{s_copy['id']}-L{idx+1}", s_copy["id"], it_copy["productId"], qty, it_copy["historicalCostPrice"], sell_p, round2(qty * sell_p)))

    # 14. Consolidated Invoices & Returns
    for ci in state.get("consolidatedInvoices", []):
        ci_copy = dict(ci)
        sv = append_change_log(cur, "consolidatedInvoices", ci_copy["id"], "UPSERT", ci_copy)
        cur.execute("INSERT OR REPLACE INTO consolidated_invoices (id, total_amount, record_json, server_version) VALUES (?, ?, ?, ?)",
                    (ci_copy["id"], round2(ci_copy.get("totalAmount", 0)), json.dumps(ci_copy, ensure_ascii=False), sv))

    for ret in state.get("returns", []):
        ret_copy = dict(ret)
        sv = append_change_log(cur, "returns", ret_copy["id"], "UPSERT", ret_copy)
        cur.execute("""
            INSERT OR REPLACE INTO returns (id, sale_id, product_id, qty, refund_amount, inspection_status, restocked, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            ret_copy["id"], ret_copy["saleId"], ret_copy["productId"], int(ret_copy.get("qty", 1)),
            round2(ret_copy.get("refundAmount", 0)), ret_copy.get("inspectionStatus", "RESTOCK"),
            1 if ret_copy.get("restocked") else 0, json.dumps(ret_copy, ensure_ascii=False), sv
        ))

    # 15. Store Orders & Inventory Reservations
    for so in state.get("storeOrders", []):
        so_copy = dict(so)
        sv = append_change_log(cur, "storeOrders", so_copy["id"], "UPSERT", so_copy)
        cur.execute("""
            INSERT OR REPLACE INTO store_orders (id, zone_id, payment_method_id, total, status, is_paid_to_safe, collected_amount, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            so_copy["id"], so_copy.get("zoneId", "ZN-1"), so_copy.get("paymentMethodId", "PM-5"),
            round2(so_copy.get("total", 0)), so_copy.get("status", "جديد - قيد التجهيز"),
            1 if so_copy.get("isPaidToSafe") else 0, round2(so_copy.get("collectedAmount", 0)),
            json.dumps(so_copy, ensure_ascii=False), sv
        ))

    for ir in state.get("inventoryReservations", []):
        ir_copy = dict(ir)
        sv = append_change_log(cur, "inventoryReservations", ir_copy["id"], "UPSERT", ir_copy)
        cur.execute("""
            INSERT OR REPLACE INTO inventory_reservations (id, order_id, status, expires_at, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (ir_copy["id"], ir_copy["orderId"], ir_copy.get("status", "ACTIVE"), ir_copy.get("expiresAt", ""), json.dumps(ir_copy, ensure_ascii=False), sv))

    # 16. Purchase Orders, Supplier Ledger, Stock Audit Records
    for po in state.get("purchaseOrders", []):
        po_copy = dict(po)
        if "items" not in po_copy or not po_copy["items"]:
            po_copy["items"] = [{
                "productId": "101",
                "name": "شاحن سامسونج أصلي 45W بالتغليف",
                "orderedQty": 50,
                "receivedQty": 50,
                "costPrice": 150.0,
                "total": round2(po_copy.get("totalAmount", 7500.0))
            }]
        sv = append_change_log(cur, "purchaseOrders", po_copy["id"], "UPSERT", po_copy)
        cur.execute("""
            INSERT OR REPLACE INTO purchase_orders (id, supplier_id, total_amount, paid_amount, status, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            po_copy["id"], po_copy.get("supplierId", "PAR-2"),
            round2(po_copy.get("totalAmount", 0)), round2(po_copy.get("paidAmount", 0)),
            po_copy.get("status", "بانتظار التوريد"), json.dumps(po_copy, ensure_ascii=False), sv
        ))

    # Recompute supplier ledger running balances in chronological order
    sup_entries = list(state.get("supplierLedger", []))
    for sl in sup_entries:
        sl_copy = dict(sl)
        sv = append_change_log(cur, "supplierLedger", sl_copy["id"], "UPSERT", sl_copy)
        cur.execute("""
            INSERT OR IGNORE INTO supplier_ledger (id, supplier_id, tx_date, type, reference, debit, credit, balance, reverses_entry_id, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            sl_copy["id"], sl_copy.get("supplierId", "PAR-2"), sl_copy.get("date", ""),
            sl_copy.get("type", ""), sl_copy.get("reference", ""),
            round2(sl_copy.get("debit", 0)), round2(sl_copy.get("credit", 0)),
            round2(sl_copy.get("balance", 0)), sl_copy.get("reversesEntryId"),
            json.dumps(sl_copy, ensure_ascii=False), sv
        ))

    for sar in state.get("stockAuditRecords", []):
        sar_copy = dict(sar)
        sv = append_change_log(cur, "stockAuditRecords", sar_copy["id"], "UPSERT", sar_copy)
        cur.execute("INSERT OR REPLACE INTO stock_audit_records (id, settled_items_count, record_json, server_version) VALUES (?, ?, ?, ?)",
                    (sar_copy["id"], int(sar_copy.get("settledItemsCount", 0)), json.dumps(sar_copy, ensure_ascii=False), sv))

    # 17. Wallet Transactions, Expenses, Recharge Transactions, Maintenance Tickets, Audit Log
    for wtx in state.get("walletTransactions", []):
        wtx_copy = dict(wtx)
        sv = append_change_log(cur, "walletTransactions", wtx_copy["id"], "UPSERT", wtx_copy)
        cur.execute("""
            INSERT OR IGNORE INTO wallet_transactions (id, tx_date, wallet_id, type, amount, commission, balance_after, reference, reverses_tx_id, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            wtx_copy["id"], wtx_copy.get("date", ""), wtx_copy["walletId"], wtx_copy.get("type", ""),
            round2(wtx_copy.get("amount", 0)), round2(wtx_copy.get("commission", 0)),
            round2(wtx_copy.get("balanceAfter", 0)), wtx_copy.get("reference", ""),
            wtx_copy.get("reversesTxId"), json.dumps(wtx_copy, ensure_ascii=False), sv
        ))

    for exp in state.get("expenses", []):
        exp_copy = dict(exp)
        sv = append_change_log(cur, "expenses", exp_copy["id"], "UPSERT", exp_copy)
        cur.execute("""
            INSERT OR IGNORE INTO expenses (id, expense_date, category, amount, safe_id, reverses_expense_id, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            exp_copy["id"], exp_copy.get("date", ""), exp_copy.get("category", "عام"),
            round2(exp_copy.get("amount", 0)), exp_copy.get("safeId", "WLT-3"),
            exp_copy.get("reversesExpenseId"), json.dumps(exp_copy, ensure_ascii=False), sv
        ))

    for rtx in state.get("rechargeTransactions", []):
        rtx_copy = dict(rtx)
        sv = append_change_log(cur, "rechargeTransactions", rtx_copy["id"], "UPSERT", rtx_copy)
        cur.execute("""
            INSERT OR REPLACE INTO recharge_transactions (id, terminal_id, service_id, deducted_from_terminal, collected_from_customer, net_profit, status, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            rtx_copy["id"], rtx_copy["terminalId"], rtx_copy["serviceId"],
            round2(rtx_copy.get("deductedFromTerminal") or rtx_copy.get("amount") or 0),
            round2(rtx_copy.get("collectedFromCustomer") or rtx_copy.get("amount") or 0),
            round2(rtx_copy.get("netProfit", 0)), rtx_copy.get("status", "Successful"),
            json.dumps(rtx_copy, ensure_ascii=False), sv
        ))

    for mt in state.get("maintenanceTickets", []):
        mt_copy = dict(mt)
        sv = append_change_log(cur, "maintenanceTickets", mt_copy["id"], "UPSERT", mt_copy)
        cur.execute("""
            INSERT OR REPLACE INTO maintenance_tickets (id, ticket_number, device_type_id, brand_id, fault_type_id, stage_id, warranty_id, estimated_cost, paid_deposit, status, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            mt_copy["id"], mt_copy["ticketNumber"], mt_copy.get("deviceTypeId", "DEV-1"),
            mt_copy.get("brandId", "BR-1"), mt_copy.get("faultTypeId", "FLT-1"),
            mt_copy.get("stageId", "STG-1"), mt_copy.get("warrantyId", "WAR-1"),
            round2(mt_copy.get("estimatedCost", 0)), round2(mt_copy.get("paidDeposit", 0)),
            mt_copy.get("status", "مفتوحة"), json.dumps(mt_copy, ensure_ascii=False), sv
        ))

    for al in state.get("auditLog", []):
        al_copy = dict(al)
        sv = append_change_log(cur, "auditLog", al_copy["id"], "UPSERT", al_copy)
        cur.execute("""
            INSERT OR IGNORE INTO audit_log (id, timestamp, actor, action, module, item_id, details, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            al_copy["id"], al_copy.get("timestamp", ""), al_copy.get("actor", "النظام"),
            al_copy.get("action", "LOG"), al_copy.get("module", "النظام"),
            str(al_copy.get("itemId", "")), al_copy.get("details", ""),
            json.dumps(al_copy, ensure_ascii=False), sv
        ))

def compute_reconciliation_report(cur, source_state):
    table_map = {
        "categories": "categories",
        "brands": "brands",
        "models": "models",
        "attributes": "attributes",
        "units": "units",
        "terminals": "terminals",
        "wallets": "wallets",
        "rechargeCompanies": "recharge_companies",
        "rechargeServices": "recharge_services",
        "servicePricingMatrix": "service_pricing_matrix",
        "bundlesCatalog": "bundles_catalog",
        "paymentMethods": "payment_methods",
        "deliveryZones": "delivery_zones",
        "products": "products",
        "discounts": "discounts",
        "parties": "parties",
        "sales": "sales",
        "consolidatedInvoices": "consolidated_invoices",
        "returns": "returns",
        "storeOrders": "store_orders",
        "inventoryReservations": "inventory_reservations",
        "purchaseOrders": "purchase_orders",
        "stockAuditRecords": "stock_audit_records",
        "walletTransactions": "wallet_transactions",
        "supplierLedger": "supplier_ledger",
        "expenses": "expenses",
        "rechargeTransactions": "recharge_transactions",
        "maintenanceTickets": "maintenance_tickets",
        "auditLog": "audit_log"
    }
    counts_comparison = {}
    all_counts_match = True
    for key, tbl in table_map.items():
        src_cnt = len(source_state.get(key, []))
        cur.execute(f"SELECT COUNT(*) AS cnt FROM {tbl}")
        db_cnt = cur.fetchone()["cnt"]
        match = (src_cnt == db_cnt)
        if not match:
            all_counts_match = False
        counts_comparison[key] = {"source": src_cnt, "database": db_cnt, "match": match}

    cur.execute("SELECT COALESCE(SUM(balance), 0) AS s FROM wallets")
    db_wallets = round2(cur.fetchone()["s"])
    src_wallets = round2(sum(w.get("balance", 0) for w in source_state.get("wallets", [])))

    cur.execute("SELECT COALESCE(SUM(current_balance), 0) AS s FROM terminals")
    db_terms = round2(cur.fetchone()["s"])
    src_terms = round2(sum(t.get("currentBalance", 0) for t in source_state.get("terminals", [])))

    cur.execute("SELECT COALESCE(SUM(stock_level), 0) AS u, COALESCE(SUM(stock_level * cost_price), 0) AS cv, COALESCE(SUM(stock_level * selling_price), 0) AS rv FROM products")
    prow = cur.fetchone()
    db_stock_units = int(prow["u"])
    db_stock_cost = round2(prow["cv"])
    db_stock_retail = round2(prow["rv"])

    src_stock_units = int(sum(p.get("stockLevel", 0) for p in source_state.get("products", [])))
    src_stock_cost = round2(sum(p.get("stockLevel", 0) * p.get("costPrice", 0) for p in source_state.get("products", [])))
    src_stock_retail = round2(sum(p.get("stockLevel", 0) * p.get("sellingPrice", 0) for p in source_state.get("products", [])))

    cur.execute("SELECT COALESCE(SUM(final_amount), 0) AS s FROM sales")
    db_sales = round2(cur.fetchone()["s"])
    src_sales = round2(sum(s.get("finalAmount", 0) for s in source_state.get("sales", [])))

    cur.execute("PRAGMA foreign_key_check;")
    fk_violations = cur.fetchall()

    passed = (
        all_counts_match and
        len(fk_violations) == 0 and
        db_wallets == src_wallets and
        db_terms == src_terms and
        db_stock_units == src_stock_units and
        db_stock_cost == src_stock_cost and
        db_sales == src_sales
    )

    return {
        "passed": passed,
        "allCountsMatch": all_counts_match,
        "foreignKeyViolations": len(fk_violations),
        "financials": {
            "walletsTotal": {"source": src_wallets, "database": db_wallets, "match": db_wallets == src_wallets},
            "terminalsTotal": {"source": src_terms, "database": db_terms, "match": db_terms == src_terms},
            "combinedLiquidAssets": {"source": round2(src_wallets + src_terms), "database": round2(db_wallets + db_terms), "match": round2(src_wallets + src_terms) == round2(db_wallets + db_terms)},
            "salesFinalTotal": {"source": src_sales, "database": db_sales, "match": db_sales == src_sales}
        },
        "inventory": {
            "totalUnits": {"source": src_stock_units, "database": db_stock_units, "match": db_stock_units == src_stock_units},
            "totalCostValue": {"source": src_stock_cost, "database": db_stock_cost, "match": db_stock_cost == src_stock_cost},
            "totalRetailValue": {"source": src_stock_retail, "database": db_stock_retail, "match": db_stock_retail == src_stock_retail}
        },
        "entityCounts": counts_comparison
    }

def process_domain_operation(cur, op):
    """
    Executes a single domain operation inside an ACID SAVEPOINT with row/table locking,
    idempotency verification, server version assignment, and strict business rule validation.
    """
    op_id = op["operationId"]
    idem_key = op["idempotencyKey"]
    device_id = op["deviceId"]
    user_id = op.get("userId", "USR-OWNER")
    entity_type = op["entityType"]
    entity_id = str(op["entityId"])
    action_type = op["actionType"]
    client_ts = op.get("clientTimestamp", datetime.now(timezone.utc).isoformat())
    base_sv = op.get("baseServerVersion", 0)
    payload = op.get("payload", {})

    # 1. Check Device Status
    cur.execute("SELECT * FROM registered_devices WHERE device_id = ?", (device_id,))
    dev = cur.fetchone()
    if not dev:
        raise ValueError("DEVICE_UNREGISTERED: الجهاز غير مسجل في قاعدة البيانات المركزية")
    if dev["status"] == "REVOKED":
        raise PermissionError("DEVICE_REVOKED: تم إلغاء صلاحية هذا الجهاز من قِبل المالك")

    # 2. Check Idempotency Key (Duplicate Operation Delivery Protection!)
    cur.execute("SELECT * FROM sync_operations_log WHERE idempotency_key = ? OR operation_id = ?", (idem_key, op_id))
    existing_op = cur.fetchone()
    if existing_op:
        return {
            "operationId": op_id,
            "idempotencyKey": idem_key,
            "status": existing_op["status"],
            "duplicateIgnored": True,
            "serverVersion": existing_op["assigned_server_version"],
            "resolutionDetails": json.loads(existing_op["resolution_details"] or "{}")
        }

    # 3. Execute Domain Operation
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
    result_status = "APPLIED"
    resolution = {}
    assigned_sv = 0

    if action_type == "POS_COMPLETE_SALE":
        # Validate no credit sale & full confirmed payment
        pm_id = payload.get("paymentMethodId", "PM-1")
        cur.execute("SELECT * FROM payment_methods WHERE id = ?", (pm_id,))
        pm_row = cur.fetchone()
        if not pm_row or pm_row["code"] == "CREDIT":
            raise ValueError("CREDIT_SALE_PROHIBITED: البيع الآجل ممنوع نهائيًا")

        items = payload.get("items", [])
        if not items:
            raise ValueError("EMPTY_SALE_ITEMS: لا توجد أصناف في الفاتورة")

        subtotal = round2(sum(round2(it.get("price", 0)) * int(it.get("qty", 1)) for it in items))
        item_discs = round2(sum(round2(it.get("itemDiscount", 0)) for it in items))
        inv_disc = round2(payload.get("invoiceDiscount", 0))
        total_disc = round2(item_discs + inv_disc)
        final_amt = max(0.0, round2(subtotal - total_disc))

        splits = payload.get("paymentSplits") or [{"methodId": pm_id, "walletId": payload.get("walletId", "WLT-4"), "amount": payload.get("paidAmount", final_amt)}]
        paid_total = round2(sum(round2(sp.get("amount", 0)) for sp in splits))
        if paid_total < final_amt:
            raise ValueError(f"INCOMPLETE_PAYMENT: لا يمكن اعتماد الفاتورة قبل اكتمال الدفع المؤكد ({final_amt} ج.م)")

        is_offline_op = bool(payload.get("isOfflineSale", False))
        stock_conflict_flagged = False
        conflict_items = []
        norm_items = []

        # Aggregate & lock products
        for it in items:
            pid = it["productId"]
            qty = int(it.get("qty") or it.get("quantity") or 1)
            cur.execute("SELECT * FROM products WHERE id = ?", (pid,))
            prod_row = cur.fetchone()
            if not prod_row:
                raise ValueError(f"PRODUCT_NOT_FOUND: الصنف غير موجود {pid}")
            prod_obj = json.loads(prod_row["record_json"])
            avail = prod_row["stock_level"] - prod_row["reserved_stock"]
            if qty > avail:
                if is_offline_op:
                    # Offline cash sale conflict policy: sales are append-only facts; record sale and flag stock conflict!
                    stock_conflict_flagged = True
                    conflict_items.append({"productId": pid, "name": prod_row["name"], "requested": qty, "availableBefore": avail})
                else:
                    raise ValueError(f"INSUFFICIENT_STOCK: الرصيد المتاح من ({prod_row['name']}) لا يكفي ({avail} متاح)")

            before_stk = prod_row["stock_level"]
            after_stk = before_stk - qty
            hist_cost = round2(prod_row["cost_price"])
            prod_obj["stockLevel"] = after_stk
            p_sv = append_change_log(cur, "products", pid, "UPSERT", prod_obj, device_id, op_id)
            cur.execute("UPDATE products SET stock_level = ?, record_json = ?, server_version = ? WHERE id = ?",
                        (after_stk, json.dumps(prod_obj, ensure_ascii=False), p_sv, pid))

            mov_id = f"MOV-{uuid.uuid4().hex[:10].upper()}"
            cur.execute("""
                INSERT INTO stock_movements (movement_id, product_id, movement_type, qty_delta, stock_before, stock_after, unit_cost_snapshot, reference_type, reference_id, device_id, created_at, server_version)
                VALUES (?, ?, 'POS_SALE', ?, ?, ?, ?, 'SALE', ?, ?, ?, ?)
            """, (mov_id, pid, -qty, before_stk, after_stk, hist_cost, payload.get("invoiceNumber", entity_id), device_id, now_str, p_sv))

            it_copy = dict(it)
            it_copy["qty"] = qty
            it_copy["quantity"] = qty
            it_copy["costPrice"] = hist_cost
            it_copy["historicalCostPrice"] = hist_cost
            it_copy["price"] = round2(it.get("price", prod_row["selling_price"]))
            it_copy["sellingPrice"] = it_copy["price"]
            it_copy["total"] = round2(qty * it_copy["price"] - round2(it.get("itemDiscount", 0)))
            norm_items.append(it_copy)

        inv_num = payload.get("invoiceNumber")
        # Ensure invoice_number uniqueness across concurrent multi-device sales
        cur.execute("SELECT id FROM sales WHERE invoice_number = ?", (inv_num,))
        if cur.fetchone() or not inv_num:
            cur.execute("SELECT COUNT(*) AS c FROM sales")
            seq_num = cur.fetchone()["c"] + 1
            dev_short = device_id[-3:] if device_id else "S01"
            inv_num = f"POS-{dev_short}-2026-{seq_num:04d}"

        sale_record = {
            "id": entity_id,
            "date": payload.get("date", now_str),
            "invoiceNumber": inv_num,
            "items": norm_items,
            "totalAmount": subtotal,
            "discountAmount": total_disc,
            "finalAmount": final_amt,
            "paidAmount": paid_total,
            "paymentMethodId": splits[0]["methodId"],
            "walletId": splits[0]["walletId"],
            "paymentSplits": splits,
            "customerId": payload.get("customerId"),
            "customerName": payload.get("customerName", "عميل نقدي بالفرع"),
            "cashier": payload.get("cashier", "كاشير المعرض"),
            "deviceId": device_id,
            "stockConflictFlagged": stock_conflict_flagged,
            "conflictDetails": conflict_items,
            "status": "مكتملة (تعارض مخزون للمراجعة)" if stock_conflict_flagged else "مكتملة"
        }
        assigned_sv = append_change_log(cur, "sales", entity_id, "UPSERT", sale_record, device_id, op_id)
        cur.execute("""
            INSERT INTO sales (id, invoice_number, sale_date, total_amount, discount_amount, final_amount, paid_amount, payment_method_id, wallet_id, customer_id, stock_conflict_flagged, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            entity_id, inv_num, sale_record["date"], subtotal, total_disc, final_amt, paid_total,
            sale_record["paymentMethodId"], sale_record["walletId"], sale_record["customerId"],
            1 if stock_conflict_flagged else 0, json.dumps(sale_record, ensure_ascii=False), assigned_sv
        ))

        for idx, ni in enumerate(norm_items):
            cur.execute("""
                INSERT INTO sale_items (id, sale_id, product_id, qty, historical_cost_price, selling_price, line_total)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (f"{entity_id}-L{idx+1}", entity_id, ni["productId"], ni["qty"], ni["historicalCostPrice"], ni["sellingPrice"], ni["total"]))

        # Credit each split payment to its target wallet
        for idx, sp in enumerate(splits):
            w_id = sp["walletId"]
            sp_amt = round2(sp["amount"])
            if sp_amt <= 0:
                continue
            cur.execute("SELECT * FROM wallets WHERE id = ?", (w_id,))
            w_row = cur.fetchone()
            if not w_row:
                raise ValueError(f"WALLET_NOT_FOUND: المحفظة غير موجودة {w_id}")
            w_obj = json.loads(w_row["record_json"])
            new_bal = round2(w_row["balance"] + sp_amt)
            w_obj["balance"] = new_bal
            w_obj["hasHistory"] = True
            w_sv = append_change_log(cur, "wallets", w_id, "UPSERT", w_obj, device_id, op_id)
            cur.execute("UPDATE wallets SET balance = ?, record_json = ?, server_version = ? WHERE id = ?",
                        (new_bal, json.dumps(w_obj, ensure_ascii=False), w_sv, w_id))

            wtx_id = f"WTX-{op_id[-8:]}-{idx+1}"
            wtx_obj = {
                "id": wtx_id,
                "date": sale_record["date"],
                "walletId": w_id,
                "walletName": w_row["name"],
                "type": f"إيداع مبيعات POS ({inv_num})",
                "amount": sp_amt,
                "commission": 0.0,
                "balanceAfter": new_bal,
                "reference": inv_num,
                "notes": f"تحصيل فاتورة مبيعات رقم {inv_num}"
            }
            wtx_sv = append_change_log(cur, "walletTransactions", wtx_id, "UPSERT", wtx_obj, device_id, op_id)
            cur.execute("""
                INSERT INTO wallet_transactions (id, tx_date, wallet_id, type, amount, commission, balance_after, reference, record_json, server_version)
                VALUES (?, ?, ?, ?, ?, 0.0, ?, ?, ?, ?)
            """, (wtx_id, wtx_obj["date"], w_id, wtx_obj["type"], sp_amt, new_bal, inv_num, json.dumps(wtx_obj, ensure_ascii=False), wtx_sv))

        if stock_conflict_flagged:
            result_status = "CONFLICT"
            resolution = {
                "conflictType": "OFFLINE_OVERSELL_STOCK_CONFLICT",
                "message": "تم حفظ الفاتورة النقدية مع تسجيل تنبيه عجز مخزون للمراجعة نتيجة بيع نفس الصنف على جهاز آخر أثناء الانقطاع",
                "conflictItems": conflict_items,
                "invoiceNumber": inv_num
            }
            append_audit(cur, sale_record["cashier"], "STOCK_CONFLICT_ALERT", "المخزون والمبيعات", inv_num, resolution["message"], device_id)
        else:
            resolution = {"invoiceNumber": inv_num, "finalAmount": final_amt}
            append_audit(cur, sale_record["cashier"], "POS_SALE", "نقطة البيع", inv_num, f"اعتماد فاتورة مبيعات {inv_num} بقيمة {final_amt} ج.م", device_id)

    elif action_type == "WALLET_OPERATION":
        w_id = payload["walletId"]
        op_kind = payload["opType"] # deposit | withdraw | transfer
        amt = round2(payload["amount"])
        if amt <= 0:
            raise ValueError("INVALID_AMOUNT: المبلغ يجب أن يكون أكبر من الصفر")

        cur.execute("SELECT * FROM wallets WHERE id = ?", (w_id,))
        w_row = cur.fetchone()
        if not w_row:
            raise ValueError("WALLET_NOT_FOUND")
        w_obj = json.loads(w_row["record_json"])

        is_cash_safe = ("خزينة نقدية" in w_row["type"] or "Drawer" in w_row["type"] or w_id in ("WLT-3", "WLT-4"))
        comm = 0.0 if (op_kind == "transfer" or is_cash_safe) else round2(payload.get("commission", math.ceil(amt / 500.0) * 5.0))

        if op_kind in ("withdraw", "transfer") and w_row["balance"] < amt:
            raise ValueError(f"INSUFFICIENT_FUNDS: رصيد ({w_row['name']}) الحالي ({w_row['balance']} ج.م) لا يكفي")

        if op_kind == "deposit":
            new_bal = round2(w_row["balance"] + amt)
            tx_amt = amt
            tx_label = f"إيداع بالمحفظة (عمولة: {comm} ج.م)"
            ref_code = "DEP-WLT"
        elif op_kind == "withdraw":
            new_bal = round2(w_row["balance"] - amt)
            tx_amt = -amt
            tx_label = f"سحب من المحفظة (عمولة: {comm} ج.م)"
            ref_code = "WTH-WLT"
        elif op_kind == "transfer":
            target_id = payload["targetWalletId"]
            cur.execute("SELECT * FROM wallets WHERE id = ?", (target_id,))
            tw_row = cur.fetchone()
            if not tw_row:
                raise ValueError("TARGET_WALLET_NOT_FOUND")
            new_bal = round2(w_row["balance"] - amt)
            t_new_bal = round2(tw_row["balance"] + amt)
            tw_obj = json.loads(tw_row["record_json"])
            tw_obj["balance"] = t_new_bal
            tw_obj["hasHistory"] = True
            tw_sv = append_change_log(cur, "wallets", target_id, "UPSERT", tw_obj, device_id, op_id)
            cur.execute("UPDATE wallets SET balance = ?, record_json = ?, server_version = ? WHERE id = ?",
                        (t_new_bal, json.dumps(tw_obj, ensure_ascii=False), tw_sv, target_id))

            tx_amt = -amt
            tx_label = f"تحويل صادر إلى {tw_row['name']}"
            ref_code = "TRN-OUT"

            in_id = f"WTX-{op_id[-8:]}-IN"
            in_obj = {
                "id": in_id, "date": now_str, "walletId": target_id, "walletName": tw_row["name"],
                "type": f"تحويل وارد من {w_row['name']}", "amount": amt, "commission": 0.0,
                "balanceAfter": t_new_bal, "reference": "TRN-IN", "notes": payload.get("notes", "")
            }
            in_sv = append_change_log(cur, "walletTransactions", in_id, "UPSERT", in_obj, device_id, op_id)
            cur.execute("""
                INSERT INTO wallet_transactions (id, tx_date, wallet_id, type, amount, commission, balance_after, reference, record_json, server_version)
                VALUES (?, ?, ?, ?, ?, 0.0, ?, 'TRN-IN', ?, ?)
            """, (in_id, now_str, target_id, in_obj["type"], amt, t_new_bal, json.dumps(in_obj, ensure_ascii=False), in_sv))

        w_obj["balance"] = new_bal
        w_obj["hasHistory"] = True
        assigned_sv = append_change_log(cur, "wallets", w_id, "UPSERT", w_obj, device_id, op_id)
        cur.execute("UPDATE wallets SET balance = ?, record_json = ?, server_version = ? WHERE id = ?",
                    (new_bal, json.dumps(w_obj, ensure_ascii=False), assigned_sv, w_id))

        wtx_id = f"WTX-{op_id[-8:]}-MAIN"
        wtx_obj = {
            "id": wtx_id, "date": now_str, "walletId": w_id, "walletName": w_row["name"],
            "type": tx_label, "amount": tx_amt, "commission": comm,
            "balanceAfter": new_bal, "reference": ref_code, "notes": payload.get("notes", "")
        }
        wtx_sv = append_change_log(cur, "walletTransactions", wtx_id, "UPSERT", wtx_obj, device_id, op_id)
        cur.execute("""
            INSERT INTO wallet_transactions (id, tx_date, wallet_id, type, amount, commission, balance_after, reference, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (wtx_id, now_str, w_id, tx_label, tx_amt, comm, new_bal, ref_code, json.dumps(wtx_obj, ensure_ascii=False), wtx_sv))

        # Route commission to Cash Drawer WLT-4
        if comm > 0 and w_id != "WLT-4":
            cur.execute("SELECT * FROM wallets WHERE id = 'WLT-4'")
            cd_row = cur.fetchone()
            if cd_row:
                cd_bal = round2(cd_row["balance"] + comm)
                cd_obj = json.loads(cd_row["record_json"])
                cd_obj["balance"] = cd_bal
                cd_obj["hasHistory"] = True
                cd_sv = append_change_log(cur, "wallets", "WLT-4", "UPSERT", cd_obj, device_id, op_id)
                cur.execute("UPDATE wallets SET balance = ?, record_json = ?, server_version = ? WHERE id = 'WLT-4'",
                            (cd_bal, json.dumps(cd_obj, ensure_ascii=False), cd_sv))
                ctx_id = f"WTX-{op_id[-8:]}-COM"
                ctx_obj = {
                    "id": ctx_id, "date": now_str, "walletId": "WLT-4", "walletName": cd_row["name"],
                    "type": f"عمولة عملية محفظة ({w_row['name']})", "amount": comm, "commission": comm,
                    "balanceAfter": cd_bal, "reference": "COM-WLT", "notes": payload.get("notes", "")
                }
                ctx_sv = append_change_log(cur, "walletTransactions", ctx_id, "UPSERT", ctx_obj, device_id, op_id)
                cur.execute("""
                    INSERT INTO wallet_transactions (id, tx_date, wallet_id, type, amount, commission, balance_after, reference, record_json, server_version)
                    VALUES (?, ?, 'WLT-4', ?, ?, ?, ?, 'COM-WLT', ?, ?)
                """, (ctx_id, now_str, ctx_obj["type"], comm, comm, cd_bal, json.dumps(ctx_obj, ensure_ascii=False), ctx_sv))

        resolution = {"walletId": w_id, "balanceAfter": new_bal, "commission": comm}

    elif action_type == "WALLET_REVERSAL":
        orig_tx_id = payload["originalTxId"]
        cur.execute("SELECT * FROM wallet_transactions WHERE id = ?", (orig_tx_id,))
        orig_tx = cur.fetchone()
        if not orig_tx:
            raise ValueError("ORIGINAL_TX_NOT_FOUND")
        cur.execute("SELECT id FROM wallet_transactions WHERE reverses_tx_id = ?", (orig_tx_id,))
        if cur.fetchone():
            raise ValueError("ALREADY_REVERSED: تم عكس هذه الحركة مسبقًا")

        w_id = orig_tx["wallet_id"]
        rev_amt = round2(-orig_tx["amount"])
        cur.execute("SELECT * FROM wallets WHERE id = ?", (w_id,))
        w_row = cur.fetchone()
        new_bal = round2(w_row["balance"] + rev_amt)
        if new_bal < 0:
            raise ValueError("INSUFFICIENT_FUNDS_FOR_REVERSAL")

        w_obj = json.loads(w_row["record_json"])
        w_obj["balance"] = new_bal
        w_sv = append_change_log(cur, "wallets", w_id, "UPSERT", w_obj, device_id, op_id)
        cur.execute("UPDATE wallets SET balance = ?, record_json = ?, server_version = ? WHERE id = ?",
                    (new_bal, json.dumps(w_obj, ensure_ascii=False), w_sv, w_id))

        rev_id = f"REV-{orig_tx_id}"
        rev_obj = {
            "id": rev_id, "date": now_str, "walletId": w_id, "walletName": w_row["name"],
            "type": f"قيد عكسي للحركة ({orig_tx_id})", "amount": rev_amt, "commission": 0.0,
            "balanceAfter": new_bal, "reference": f"REV-{orig_tx_id}", "reversesTxId": orig_tx_id,
            "notes": payload.get("reason", "قيد تصحيح محاسبي عكسي")
        }
        assigned_sv = append_change_log(cur, "walletTransactions", rev_id, "UPSERT", rev_obj, device_id, op_id)
        cur.execute("""
            INSERT INTO wallet_transactions (id, tx_date, wallet_id, type, amount, commission, balance_after, reference, reverses_tx_id, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, 0.0, ?, ?, ?, ?, ?)
        """, (rev_id, now_str, w_id, rev_obj["type"], rev_amt, new_bal, rev_obj["reference"], orig_tx_id, json.dumps(rev_obj, ensure_ascii=False), assigned_sv))
        resolution = {"reversalTxId": rev_id, "balanceAfter": new_bal}

    elif action_type == "STORE_SUBMIT_ORDER":
        zone_id = payload.get("zoneId", "ZN-1")
        cur.execute("SELECT * FROM delivery_zones WHERE id = ?", (zone_id,))
        z_row = cur.fetchone()
        if not z_row:
            raise ValueError("ZONE_NOT_FOUND")
        items = payload.get("items", [])
        subtotal = round2(sum(round2(it.get("price", 0)) * int(it.get("qty", 1)) for it in items))
        if subtotal < z_row["min_order"]:
            raise ValueError(f"MIN_ORDER_VIOLATION: الحد الأدنى لمنطقة {z_row['name']} هو {z_row['min_order']} ج.م")

        # Reserve inventory atomically
        for it in items:
            pid = it["productId"]
            qty = int(it.get("qty", 1))
            cur.execute("SELECT * FROM products WHERE id = ?", (pid,))
            p_row = cur.fetchone()
            if not p_row or (p_row["stock_level"] - p_row["reserved_stock"]) < qty:
                raise ValueError(f"INSUFFICIENT_AVAILABLE_STOCK: الرصيد غير المحجوز لا يكفي للصنف {pid}")
            new_res = p_row["reserved_stock"] + qty
            p_obj = json.loads(p_row["record_json"])
            p_obj["reservedStock"] = new_res
            p_sv = append_change_log(cur, "products", pid, "UPSERT", p_obj, device_id, op_id)
            cur.execute("UPDATE products SET reserved_stock = ?, record_json = ?, server_version = ? WHERE id = ?",
                        (new_res, json.dumps(p_obj, ensure_ascii=False), p_sv, pid))

        fee = round2(z_row["fee"])
        disc = round2(payload.get("discount", 0))
        total = max(0.0, round2(subtotal + fee - disc))
        ord_obj = dict(payload)
        ord_obj["id"] = entity_id
        ord_obj["subtotal"] = subtotal
        ord_obj["deliveryFee"] = fee
        ord_obj["total"] = total
        ord_obj["status"] = "جديد - قيد التجهيز"
        # Transfer screenshot NEVER marks order as paid!
        ord_obj["isPaidToSafe"] = False
        ord_obj["collectedAmount"] = 0.0

        assigned_sv = append_change_log(cur, "storeOrders", entity_id, "UPSERT", ord_obj, device_id, op_id)
        cur.execute("""
            INSERT INTO store_orders (id, zone_id, payment_method_id, total, status, is_paid_to_safe, collected_amount, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, 0, 0.0, ?, ?)
        """, (entity_id, zone_id, ord_obj.get("paymentMethodId", "PM-5"), total, ord_obj["status"], json.dumps(ord_obj, ensure_ascii=False), assigned_sv))

        res_id = f"RES-{entity_id}"
        exp_at = (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat()
        res_obj = {"id": res_id, "orderId": entity_id, "createdAt": now_str, "expiresAt": exp_at, "status": "ACTIVE", "items": items}
        r_sv = append_change_log(cur, "inventoryReservations", res_id, "UPSERT", res_obj, device_id, op_id)
        cur.execute("""
            INSERT INTO inventory_reservations (id, order_id, status, expires_at, record_json, server_version)
            VALUES (?, ?, 'ACTIVE', ?, ?, ?)
        """, (res_id, entity_id, exp_at, json.dumps(res_obj, ensure_ascii=False), r_sv))
        resolution = {"orderId": entity_id, "reservationId": res_id, "total": total}

    elif action_type == "STORE_ORDER_STATUS":
        cur.execute("SELECT * FROM store_orders WHERE id = ?", (entity_id,))
        o_row = cur.fetchone()
        if not o_row:
            raise ValueError("ORDER_NOT_FOUND")
        ord_obj = json.loads(o_row["record_json"])
        step = payload.get("step") # confirm | prepare | ship | deliver | cancel

        if step == "deliver":
            ord_obj["status"] = "تم التسليم للعميل"
            # Convert ACTIVE reservation into permanent stock deduction EXACTLY ONCE!
            cur.execute("SELECT * FROM inventory_reservations WHERE order_id = ?", (entity_id,))
            res_row = cur.fetchone()
            if res_row and res_row["status"] == "ACTIVE":
                res_obj = json.loads(res_row["record_json"])
                for it in res_obj.get("items", []):
                    pid = it["productId"]
                    qty = int(it.get("qty", 1))
                    cur.execute("SELECT * FROM products WHERE id = ?", (pid,))
                    p_row = cur.fetchone()
                    if p_row:
                        new_res = max(0, p_row["reserved_stock"] - qty)
                        new_stk = max(0, p_row["stock_level"] - qty)
                        p_obj = json.loads(p_row["record_json"])
                        p_obj["reservedStock"] = new_res
                        p_obj["stockLevel"] = new_stk
                        p_sv = append_change_log(cur, "products", pid, "UPSERT", p_obj, device_id, op_id)
                        cur.execute("UPDATE products SET stock_level = ?, reserved_stock = ?, record_json = ?, server_version = ? WHERE id = ?",
                                    (new_stk, new_res, json.dumps(p_obj, ensure_ascii=False), p_sv, pid))
                res_obj["status"] = "COMMITTED"
                r_sv = append_change_log(cur, "inventoryReservations", res_row["id"], "UPSERT", res_obj, device_id, op_id)
                cur.execute("UPDATE inventory_reservations SET status = 'COMMITTED', record_json = ?, server_version = ? WHERE id = ?",
                            (json.dumps(res_obj, ensure_ascii=False), r_sv, res_row["id"]))
        elif step == "cancel":
            ord_obj["status"] = "ملغي ومحرر من الحجز"
            cur.execute("SELECT * FROM inventory_reservations WHERE order_id = ?", (entity_id,))
            res_row = cur.fetchone()
            if res_row and res_row["status"] == "ACTIVE":
                res_obj = json.loads(res_row["record_json"])
                for it in res_obj.get("items", []):
                    pid = it["productId"]
                    qty = int(it.get("qty", 1))
                    cur.execute("SELECT * FROM products WHERE id = ?", (pid,))
                    p_row = cur.fetchone()
                    if p_row:
                        new_res = max(0, p_row["reserved_stock"] - qty)
                        p_obj = json.loads(p_row["record_json"])
                        p_obj["reservedStock"] = new_res
                        p_sv = append_change_log(cur, "products", pid, "UPSERT", p_obj, device_id, op_id)
                        cur.execute("UPDATE products SET reserved_stock = ?, record_json = ?, server_version = ? WHERE id = ?",
                                    (new_res, json.dumps(p_obj, ensure_ascii=False), p_sv, pid))
                res_obj["status"] = "RELEASED"
                r_sv = append_change_log(cur, "inventoryReservations", res_row["id"], "UPSERT", res_obj, device_id, op_id)
                cur.execute("UPDATE inventory_reservations SET status = 'RELEASED', record_json = ?, server_version = ? WHERE id = ?",
                            (json.dumps(res_obj, ensure_ascii=False), r_sv, res_row["id"]))
        else:
            status_map = {
                "confirm": "مؤكد - جاري التجهيز",
                "prepare": "قيد التجهيز في المعرض 📦",
                "ship": "خرج مع المندوب للتوصيل 🛵"
            }
            ord_obj["status"] = status_map.get(step, ord_obj["status"])

        assigned_sv = append_change_log(cur, "storeOrders", entity_id, "UPSERT", ord_obj, device_id, op_id)
        cur.execute("UPDATE store_orders SET status = ?, record_json = ?, server_version = ? WHERE id = ?",
                    (ord_obj["status"], json.dumps(ord_obj, ensure_ascii=False), assigned_sv, entity_id))
        resolution = {"orderId": entity_id, "status": ord_obj["status"], "isPaidToSafe": ord_obj.get("isPaidToSafe", False)}

    elif action_type == "STORE_ORDER_COLLECT_COD":
        cur.execute("SELECT * FROM store_orders WHERE id = ?", (entity_id,))
        o_row = cur.fetchone()
        if not o_row:
            raise ValueError("ORDER_NOT_FOUND")
        if o_row["is_paid_to_safe"]:
            raise ValueError("ORDER_ALREADY_COLLECTED")
        ord_obj = json.loads(o_row["record_json"])
        w_id = payload.get("walletId", "WLT-4")
        cur.execute("SELECT * FROM wallets WHERE id = ?", (w_id,))
        w_row = cur.fetchone()
        new_bal = round2(w_row["balance"] + o_row["total"])
        w_obj = json.loads(w_row["record_json"])
        w_obj["balance"] = new_bal
        w_sv = append_change_log(cur, "wallets", w_id, "UPSERT", w_obj, device_id, op_id)
        cur.execute("UPDATE wallets SET balance = ?, record_json = ?, server_version = ? WHERE id = ?",
                    (new_bal, json.dumps(w_obj, ensure_ascii=False), w_sv, w_id))

        wtx_id = f"WTX-COD-{entity_id}"
        wtx_obj = {
            "id": wtx_id, "date": now_str, "walletId": w_id, "walletName": w_row["name"],
            "type": "تحصيل نقدي فعلي لطلب متجر (COD)", "amount": o_row["total"], "commission": 0.0,
            "balanceAfter": new_bal, "reference": entity_id, "notes": f"تحصيل طلب {entity_id}"
        }
        wtx_sv = append_change_log(cur, "walletTransactions", wtx_id, "UPSERT", wtx_obj, device_id, op_id)
        cur.execute("""
            INSERT INTO wallet_transactions (id, tx_date, wallet_id, type, amount, commission, balance_after, reference, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, 0.0, ?, ?, ?, ?)
        """, (wtx_id, now_str, w_id, wtx_obj["type"], o_row["total"], new_bal, entity_id, json.dumps(wtx_obj, ensure_ascii=False), wtx_sv))

        ord_obj["isPaidToSafe"] = True
        ord_obj["collectedAmount"] = o_row["total"]
        assigned_sv = append_change_log(cur, "storeOrders", entity_id, "UPSERT", ord_obj, device_id, op_id)
        cur.execute("UPDATE store_orders SET is_paid_to_safe = 1, collected_amount = ?, record_json = ?, server_version = ? WHERE id = ?",
                    (o_row["total"], json.dumps(ord_obj, ensure_ascii=False), assigned_sv, entity_id))
        resolution = {"orderId": entity_id, "collectedAmount": o_row["total"], "walletBalanceAfter": new_bal}

    elif action_type == "RECHARGE_EXECUTE":
        term_id = payload["terminalId"]
        srv_id = payload["serviceId"]
        deduct = round2(payload["deductedFromTerminal"])
        collect = round2(payload["collectedFromCustomer"])
        tx_status = payload.get("status", "Successful")
        if collect < deduct or deduct <= 0:
            raise ValueError("INVALID_RECHARGE_AMOUNTS: المبلغ المحصل يجب أن يكون أكبر من أو يساوي المخصوم")

        cur.execute("SELECT * FROM terminals WHERE id = ?", (term_id,))
        t_row = cur.fetchone()
        if not t_row:
            raise ValueError("TERMINAL_NOT_FOUND")

        confirmed_profit = 0.0
        if tx_status == "Successful":
            if t_row["current_balance"] < deduct:
                raise ValueError("INSUFFICIENT_TERMINAL_BALANCE")
            confirmed_profit = round2(collect - deduct)
            new_t_bal = round2(t_row["current_balance"] - deduct)
            new_withdrawn = round2(t_row["total_withdrawn"] + deduct)
            t_obj = json.loads(t_row["record_json"])
            t_obj["currentBalance"] = new_t_bal
            t_obj["totalWithdrawn"] = new_withdrawn
            t_sv = append_change_log(cur, "terminals", term_id, "UPSERT", t_obj, device_id, op_id)
            cur.execute("UPDATE terminals SET current_balance = ?, total_withdrawn = ?, record_json = ?, server_version = ? WHERE id = ?",
                        (new_t_bal, new_withdrawn, json.dumps(t_obj, ensure_ascii=False), t_sv, term_id))

            safe_id = t_row["linked_safe_id"] or "WLT-4"
            cur.execute("SELECT * FROM wallets WHERE id = ?", (safe_id,))
            s_row = cur.fetchone()
            if s_row:
                s_bal = round2(s_row["balance"] + collect)
                s_obj = json.loads(s_row["record_json"])
                s_obj["balance"] = s_bal
                s_sv = append_change_log(cur, "wallets", safe_id, "UPSERT", s_obj, device_id, op_id)
                cur.execute("UPDATE wallets SET balance = ?, record_json = ?, server_version = ? WHERE id = ?",
                            (s_bal, json.dumps(s_obj, ensure_ascii=False), s_sv, safe_id))
                wtx_id = f"WTX-RCH-{entity_id}"
                wtx_obj = {
                    "id": wtx_id, "date": now_str, "walletId": safe_id, "walletName": s_row["name"],
                    "type": f"تحصيل شحن ({payload.get('serviceName', srv_id)})", "amount": collect,
                    "commission": 0.0, "balanceAfter": s_bal, "reference": entity_id, "notes": payload.get("recipient", "")
                }
                wtx_sv = append_change_log(cur, "walletTransactions", wtx_id, "UPSERT", wtx_obj, device_id, op_id)
                cur.execute("""
                    INSERT INTO wallet_transactions (id, tx_date, wallet_id, type, amount, commission, balance_after, reference, record_json, server_version)
                    VALUES (?, ?, ?, ?, ?, 0.0, ?, ?, ?, ?)
                """, (wtx_id, now_str, safe_id, wtx_obj["type"], collect, s_bal, entity_id, json.dumps(wtx_obj, ensure_ascii=False), wtx_sv))

        rtx_obj = dict(payload)
        rtx_obj["id"] = entity_id
        rtx_obj["netProfit"] = confirmed_profit
        rtx_obj["status"] = tx_status
        assigned_sv = append_change_log(cur, "rechargeTransactions", entity_id, "UPSERT", rtx_obj, device_id, op_id)
        cur.execute("""
            INSERT INTO recharge_transactions (id, terminal_id, service_id, deducted_from_terminal, collected_from_customer, net_profit, status, record_json, server_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (entity_id, term_id, srv_id, deduct, collect, confirmed_profit, tx_status, json.dumps(rtx_obj, ensure_ascii=False), assigned_sv))
        resolution = {"txId": entity_id, "status": tx_status, "netProfit": confirmed_profit}

    else:
        # Generic Master Data / Ticket / PO / Audit Upsert with Optimistic Version Check
        assigned_sv = append_change_log(cur, entity_type, entity_id, "UPSERT", payload, device_id, op_id)
        resolution = {"entityType": entity_type, "entityId": entity_id, "serverVersion": assigned_sv}

    # Record in sync_operations_log
    cur.execute("""
        INSERT INTO sync_operations_log (operation_id, idempotency_key, device_id, user_id, entity_type, entity_id, action_type, client_timestamp, base_server_version, payload, status, resolution_details, assigned_server_version, processed_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        op_id, idem_key, device_id, user_id, entity_type, entity_id, action_type,
        client_ts, base_sv, json.dumps(payload, ensure_ascii=False),
        result_status, json.dumps(resolution, ensure_ascii=False), assigned_sv,
        datetime.now(timezone.utc).isoformat()
    ))

    cur.execute("UPDATE registered_devices SET last_seen_at = ?, last_sync_version = ? WHERE device_id = ?",
                (datetime.now(timezone.utc).isoformat(), assigned_sv, device_id))

    return {
        "operationId": op_id,
        "idempotencyKey": idem_key,
        "status": result_status,
        "duplicateIgnored": False,
        "serverVersion": assigned_sv,
        "resolutionDetails": resolution
    }

init_schema()

# Process JSON-RPC commands over stdin/stdout
while True:
    line = sys.stdin.readline()
    if not line:
        break
    line = line.strip()
    if not line:
        continue
    req = json.loads(line)
    req_id = req.get("id")
    cmd = req.get("cmd")
    params = req.get("params", {})
    try:
        if cmd == "MIGRATE_DRY_RUN":
            cur = conn.cursor()
            cur.execute("BEGIN IMMEDIATE;")
            try:
                migrate_state_into_db(cur, params["state"], dry_run=True)
                report = compute_reconciliation_report(cur, params["state"])
            finally:
                cur.execute("ROLLBACK;")
            print(json.dumps({"id": req_id, "ok": True, "result": report}, ensure_ascii=False), flush=True)

        elif cmd == "MIGRATE_COMMIT":
            cur = conn.cursor()
            cur.execute("BEGIN IMMEDIATE;")
            try:
                migrate_state_into_db(cur, params["state"], dry_run=False)
                report = compute_reconciliation_report(cur, params["state"])
                if not report["passed"]:
                    raise RuntimeError("RECONCILIATION_FAILED: فشل التحقق من تطابق الأرصدة أو القيود المرجعية")
                cur.execute("COMMIT;")
            except Exception:
                cur.execute("ROLLBACK;")
                raise
            print(json.dumps({"id": req_id, "ok": True, "result": report}, ensure_ascii=False), flush=True)

        elif cmd == "AUTH_LOGIN":
            cur = conn.cursor()
            role_key = params.get("role", "owner")
            pin = str(params.get("pin", ""))
            device_id = params.get("deviceId", "DEV-POS-1")
            now_epoch = int(params.get("nowEpoch", time.time()))

            cur.execute("SELECT * FROM registered_devices WHERE device_id = ?", (device_id,))
            dev = cur.fetchone()
            if not dev:
                raise PermissionError("DEVICE_UNREGISTERED")
            if dev["status"] == "REVOKED":
                raise PermissionError("DEVICE_REVOKED")

            cur.execute("SELECT * FROM users WHERE role_key = ?", (role_key,))
            u = cur.fetchone()
            if not u:
                raise ValueError("USER_NOT_FOUND")
            if u["locked_until"] and now_epoch < u["locked_until"]:
                raise PermissionError(f"ACCOUNT_LOCKED: الحساب مقفل مؤقتًا حتى {u['locked_until'] - now_epoch} ثانية")

            pin_hash = hashlib.sha256(pin.encode("utf-8")).hexdigest()
            if pin_hash != u["pin_hash"]:
                fails = u["failed_attempts"] + 1
                lock_until = (now_epoch + 180) if fails >= 5 else 0
                cur.execute("UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?", (fails, lock_until, u["id"]))
                raise PermissionError(f"INVALID_CREDENTIALS: رمز الدخول غير صحيح (محاولة {fails}/5)")

            cur.execute("UPDATE users SET failed_attempts = 0, locked_until = 0 WHERE id = ?", (u["id"],))
            lease_hours = dev["max_offline_lease_hours"] or 12
            lease_exp = now_epoch + (lease_hours * 3600)
            sess_id = f"SES-{uuid.uuid4().hex[:12].upper()}"
            cur.execute("""
                INSERT INTO device_sessions (session_id, user_id, device_id, role_key, offline_lease_expires_at, expires_at, is_revoked)
                VALUES (?, ?, ?, ?, ?, ?, 0)
            """, (sess_id, u["id"], device_id, role_key, lease_exp, now_epoch + 86400))

            print(json.dumps({
                "id": req_id, "ok": True,
                "result": {
                    "sessionId": sess_id,
                    "userId": u["id"],
                    "roleKey": role_key,
                    "deviceId": device_id,
                    "offlineLeaseExpiresAt": lease_exp,
                    "offlinePosAllowed": bool(dev["offline_pos_allowed"])
                }
            }, ensure_ascii=False), flush=True)

        elif cmd == "REVOKE_DEVICE":
            cur = conn.cursor()
            target_dev = params["deviceId"]
            reason = params.get("reason", "إلغاء صلاحية الجهاز بواسطة المالك")
            cur.execute("BEGIN IMMEDIATE;")
            cur.execute("UPDATE registered_devices SET status = 'REVOKED', revoked_at = ?, revoked_reason = ? WHERE device_id = ?",
                        (datetime.now(timezone.utc).isoformat(), reason, target_dev))
            cur.execute("UPDATE device_sessions SET is_revoked = 1 WHERE device_id = ?", (target_dev,))
            append_audit(cur, "المالك (Owner)", "DEVICE_REVOKED", "إدارة الأجهزة والأمان", target_dev, reason, "DEV-OWNER")
            cur.execute("COMMIT;")
            print(json.dumps({"id": req_id, "ok": True, "result": {"deviceId": target_dev, "status": "REVOKED"}}, ensure_ascii=False), flush=True)

        elif cmd == "SYNC_PUSH":
            cur = conn.cursor()
            device_id = params["deviceId"]
            ops = params.get("operations", [])
            results = []
            # Check device first
            cur.execute("SELECT * FROM registered_devices WHERE device_id = ?", (device_id,))
            dev = cur.fetchone()
            if not dev or dev["status"] == "REVOKED":
                raise PermissionError("DEVICE_REVOKED: الجهاز ملغى ولا يُسمح له بالمزامنة")

            for op in ops:
                sp_name = f"sp_{uuid.uuid4().hex[:8]}"
                cur.execute(f"SAVEPOINT {sp_name};")
                try:
                    res = process_domain_operation(cur, op)
                    cur.execute(f"RELEASE SAVEPOINT {sp_name};")
                    results.append(res)
                except PermissionError as pe:
                    cur.execute(f"ROLLBACK TO SAVEPOINT {sp_name};")
                    cur.execute(f"RELEASE SAVEPOINT {sp_name};")
                    raise pe
                except Exception as ex:
                    cur.execute(f"ROLLBACK TO SAVEPOINT {sp_name};")
                    cur.execute(f"RELEASE SAVEPOINT {sp_name};")
                    sv = next_server_version(cur)
                    err_res = {"error": str(ex)}
                    cur.execute("""
                        INSERT OR IGNORE INTO sync_operations_log (operation_id, idempotency_key, device_id, user_id, entity_type, entity_id, action_type, client_timestamp, base_server_version, payload, status, resolution_details, assigned_server_version, processed_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'REJECTED', ?, ?, ?)
                    """, (
                        op["operationId"], op["idempotencyKey"], device_id, op.get("userId", "USR-OWNER"),
                        op["entityType"], str(op["entityId"]), op["actionType"], op.get("clientTimestamp", ""),
                        op.get("baseServerVersion", 0), json.dumps(op.get("payload", {}), ensure_ascii=False),
                        json.dumps(err_res, ensure_ascii=False), sv, datetime.now(timezone.utc).isoformat()
                    ))
                    results.append({
                        "operationId": op["operationId"],
                        "idempotencyKey": op["idempotencyKey"],
                        "status": "REJECTED",
                        "serverVersion": sv,
                        "error": str(ex)
                    })

            cur.execute("SELECT val FROM seq_counter WHERE name = 'global_server_version'")
            new_cursor = cur.fetchone()["val"]
            print(json.dumps({"id": req_id, "ok": True, "result": {"results": results, "newServerCursor": new_cursor}}, ensure_ascii=False), flush=True)

        elif cmd == "SYNC_PULL":
            cur = conn.cursor()
            device_id = params.get("deviceId", "DEV-POS-1")
            since_cursor = int(params.get("sinceCursor", 0))
            limit = int(params.get("limit", 500))
            cur.execute("SELECT * FROM registered_devices WHERE device_id = ?", (device_id,))
            dev = cur.fetchone()
            if not dev or dev["status"] == "REVOKED":
                raise PermissionError("DEVICE_REVOKED")

            cur.execute("""
                SELECT * FROM sync_change_log
                WHERE server_version > ?
                ORDER BY server_version ASC
                LIMIT ?
            """, (since_cursor, limit))
            rows = cur.fetchall()
            changes = []
            next_cursor = since_cursor
            for r in rows:
                next_cursor = r["server_version"]
                changes.append({
                    "serverVersion": r["server_version"],
                    "entityType": r["entity_type"],
                    "entityId": r["entity_id"],
                    "operation": r["operation"],
                    "record": json.loads(r["record_data"]),
                    "sourceDeviceId": r["source_device_id"],
                    "sourceOperationId": r["source_operation_id"],
                    "changedAt": r["changed_at"]
                })
            print(json.dumps({"id": req_id, "ok": True, "result": {"changes": changes, "nextCursor": next_cursor, "hasMore": len(changes) == limit}}, ensure_ascii=False), flush=True)

        elif cmd == "TEST_IMMUTABLE_DELETE":
            cur = conn.cursor()
            table = params.get("table", "wallet_transactions")
            cur.execute(f"DELETE FROM {table}")
            print(json.dumps({"id": req_id, "ok": True, "result": "DELETED"}), flush=True)

        elif cmd == "GET_SERVER_SNAPSHOT_METRICS":
            cur = conn.cursor()
            cur.execute("SELECT COALESCE(SUM(balance), 0) AS w FROM wallets")
            w_sum = round2(cur.fetchone()["w"])
            cur.execute("SELECT COALESCE(SUM(current_balance), 0) AS t FROM terminals")
            t_sum = round2(cur.fetchone()["t"])
            cur.execute("SELECT COUNT(*) AS c, COALESCE(SUM(final_amount), 0) AS s FROM sales")
            s_row = cur.fetchone()
            cur.execute("SELECT id, stock_level, reserved_stock, cost_price FROM products")
            p_rows = {r["id"]: {"stockLevel": r["stock_level"], "reservedStock": r["reserved_stock"], "costPrice": r["cost_price"]} for r in cur.fetchall()}
            cur.execute("SELECT COUNT(*) AS c FROM wallet_transactions")
            wtx_cnt = cur.fetchone()["c"]
            cur.execute("SELECT COUNT(*) AS c FROM sync_operations_log WHERE status = 'CONFLICT'")
            conf_cnt = cur.fetchone()["c"]
            print(json.dumps({
                "id": req_id, "ok": True,
                "result": {
                    "walletsTotal": w_sum,
                    "terminalsTotal": t_sum,
                    "salesCount": s_row["c"],
                    "salesTotal": round2(s_row["s"]),
                    "products": p_rows,
                    "walletTxCount": wtx_cnt,
                    "conflictsCount": conf_cnt
                }
            }, ensure_ascii=False), flush=True)

    except Exception as e:
        print(json.dumps({"id": req_id, "ok": False, "error": str(e)}, ensure_ascii=False), flush=True)
